---
name: kicad-pcb-export-recipe
description: 纯 KiCad 10 流程配方——环境、kicad-cli 速查、pcbnew API 坑、取库、Python 生成原理图、网表/ERC 判读、Freerouting DSN/SES、A* 障碍模型、布线经验、嘉立创导出
metadata:
  type: reference
  modified: 2026-09-26
---

> 2026-09-26 改版：原文件是「嘉立创EDA Pro ↔ KiCad 导出/回灌」配方。用户规定只用 KiCad 后，
> EDA 坐标/层号映射、焊盘数组映射、zone→Fill 回灌、EDA 侧包围盒语义等内容全部删除；
> 与 EDA 无关的 KiCad/Freerouting/A* 经验原样保留并补充了 KiCad 10.0.6 实测结论。

## 0. 环境与 kicad-cli 速查

- **自检（真跑，不看 `which`）**：`kicad-cli version`（应为 10.x）、`kicad-python -c "import pcbnew;print(pcbnew.Version())"`。
  不存在就运行项目提供的安装脚本，或按 KiCad 官方方式安装。
- **chroot 包装**：若 `kicad-cli`/`kicad-python` 是 chroot 包装脚本（云端常见），**只能访问 `/home/user` 与 `/tmp`**，
  相对路径按当前目录解析。工程、脚本、输出目录都放在这两处之下。
- 启动时 `Font 'Ubuntu Sans' not found` / `Debug: Adding duplicate image handler` 之类是字体/wx 噪音，不是错误；
  过滤输出时别把真错误一起过滤掉。

| 目的 | 命令 |
|---|---|
| ERC（权威连通判据） | `kicad-cli sch erc --format json --severity-all -o erc.json root.kicad_sch` |
| 网表（并查集输入） | `kicad-cli sch export netlist --format kicadxml -o net.xml root.kicad_sch` |
| 原理图 PDF（目视） | `kicad-cli sch export pdf -o sch.pdf root.kicad_sch` |
| BOM（嘉立创格式） | `kicad-cli sch export bom --fields 'Value,Reference,Footprint,LCSC' --labels 'Comment,Designator,Footprint,LCSC Part #' --group-by 'Value,Footprint,LCSC' --ref-range-delimiter '' --exclude-dnp -o bom.csv root.kicad_sch` |
| DRC | `kicad-cli pcb drc --format json --severity-all --refill-zones --schematic-parity -o drc.json board.kicad_pcb`（`--save-board` 才会把填充写回文件） |
| Gerber | `kicad-cli pcb export gerbers -l F.Cu,In1.Cu,In2.Cu,B.Cu,F.Paste,B.Paste,F.Silkscreen,B.Silkscreen,F.Mask,B.Mask,Edge.Cuts --subtract-soldermask -o gerber/ board.kicad_pcb` |
| 钻孔 | `kicad-cli pcb export drill --excellon-separate-th -u mm --generate-report --report-path gerber/drill.txt -o gerber/ board.kicad_pcb` |
| 贴片坐标 | `kicad-cli pcb export pos --format csv --units mm --side both --exclude-dnp --exclude-fp-th -o pos.csv board.kicad_pcb` |
| IPC-2581 / ODB++ | `kicad-cli pcb export ipc2581 …` / `kicad-cli pcb export odb …`（板厂支持时作第二份交叉比对） |
| 板图 SVG/PDF（目视） | `kicad-cli pcb export svg -l F.Cu,F.Silkscreen,Edge.Cuts -o top.svg board.kicad_pcb` |

⚠ `pcb export gerbers` 不带 `-l` 会把 User/Fab/Courtyard 等十几层全导出来，打包前要挑层（`scripts/jlc_fab.py` 已处理）。
⚠ `sch export bom` 默认把连续位号压成 `R1-R4`，嘉立创要逐个列出 → `--ref-range-delimiter ''`。
⚠ `pcb export pos` 的 Y 是 KiCad 板坐标（常为负），嘉立创能识别；**旋转以下单页贴片预览为准**，部分封装的 0° 定义不同。

## 1. pcbnew（KiCad 10.0.6）API 实测坑

| 现象 | 正确做法 |
|---|---|
| `b.GetTracks()` 在某些调用场景下报 SwigPyObject not iterable | 用 `list(b.Tracks())` |
| `b.Delete(t)` 之后再调 `t.GetNetname()` → `TypeError … BOARD_CONNECTED_ITEM const *` | Delete 会释放对象：**先取需要的属性再 Delete**，`for t in list(b.Tracks()): b.Delete(t)` |
| 保存 | `pcbnew.SaveBoard(path, b)` |
| `GetBoardPolygonOutlines(poly)` 报缺参数 | 10.x 签名是 `GetBoardPolygonOutlines(poly, aInferOutlineIfNecessary)`，传 `True` |
| `SHAPE_POLY_SET.SquaredDistance(pt, True)` 刷屏 assert（"does not yet support aOutlineOnly"） | 自己遍历 `Outline(k)`/`Hole(k,h)` 的线段算点到线段距离 |
| `fp.GetBoundingBox()` 把位号/数值文字算进去，得出"整排电阻互相重叠" | 判干涉用 `fp.GetCourtyard(F_CrtYd/B_CrtYd)`；没有 courtyard 才用 `GetBoundingBox(False)` |
| 文字的 bbox 对 45° 文字大面积虚报重叠 | `text.TransformShapeToPolygon(poly, layer, 0, maxerr, ERROR_INSIDE)` 取墨迹多边形再 `BooleanIntersection` |
| 位号"画出来是几度" | `field.GetDrawRotation().AsDegrees()`（含封装旋转），再 `((a%360)+360)%360` 归一 |
| 过孔尺寸 | `via.GetDrillValue()`、`via.GetWidth(pcbnew.F_Cu)`；盲埋孔用 `via.IsOnLayer(l)` 判层跨度 |
| 焊盘多边形 | `pad.TransformShapeToPolygon(poly, layer, 0, maxerr, ERROR_INSIDE)`，NPTH 用 `TransformHoleToPolygon` |
| 覆铜岛 | `zone.GetFilledPolysList(layer)` 的每个 `Outline(k)` 是一个岛（带 `Hole(k,h)`）；要先填充（`--refill-zones` 或 GUI 按 B） |
| 连通性真值 | `b.BuildConnectivity(); b.GetConnectivity().GetUnconnectedCount(False)` —— 与 DRC `unconnected_items` 一致 |
| 泪滴 | 泪滴是 `ZONE`，`z.IsTeardropArea()` 为真 |
| **headless 下进程内新建 ZONE 后 Fill 或 SaveBoard 段错误**（stdout 未 flush 时输出全丢，假象是"无输出"） | 走线/过孔创建保存没事。zone 用文本拼接：让 pcbnew 把带 zone 的板另存为 v10 格式，按配平括号提取 `(zone …)` 块拼入目标文件（v10 里 zone 用 `(net "名字")`），再"新进程加载 → Fill → 保存" |
| 打开着的 KiCad GUI 会覆写文件 | headless 编辑期间 GUI 一保存，内存旧状态覆盖 `.kicad_pcb`/`.kicad_pro`。协作时要求用户不要在 GUI 保存；结束后让其还原重开 |

**文件语法坑（手写/生成 `.kicad_pcb` 时）**：老格式 `segment`/`via` 里只能写 `(net N)`，写 `(net N "name")` 直接解析失败；
焊盘和顶层网络声明才用带名形式。v10 保存后全部按名。生成器写老格式没问题，KiCad 读入再存自动升级。
背面封装文字要 `(justify mirror)`；字高 < 0.8 触发 `text_height`。
设计规则写进 **`.kicad_pro`**（`board.design_settings.rules` + `net_settings.classes`），DRC 才认——**拷板必拷同名 `.kicad_pro`**。

**底面镜像实证**（Gerber flash 验证）：`.kicad_pcb` 里无论 F 还是 B 面封装，焊盘落点都是 `at + R(θ)·local`（θ 正=视觉逆时针），
**底面不额外镜像**。

## 2. 取库：一律从嘉立创（easyeda2kicad）→ 验证（SKILL 规则 0e）

1. **不用 KiCad 官方库的封装**（只作对照核验）。
2. **easyeda2kicad**（v1.0.1 实测 CLI）：
   ```bash
   pip install easyeda2kicad
   easyeda2kicad --full --lcsc_id C2040 --output <工程>/lib/easyeda2kicad/ee   # 生成 ee.kicad_sym + ee.pretty + ee.3dshapes
   #  --symbol/--footprint/--3d 单项；--overwrite 覆盖；--project-relative 3D 路径相对工程；--use-cache 缓存 API 响应
   ```
   ⚠ 它访问 `easyeda.com` 的 API；**云端网络策略可能拦截**（2026-09-26 实测本容器 `CONNECT easyeda.com:443` 被 403 拒），
   这时只能在能联网的机器上转好再拷进工程。
3. **`@jlcpcb/cli`**（备选，带库存/单价/基础库标记）：
   ```bash
   npx -y @jlcpcb/cli@0.4.0 search --json --in-stock -l 20 "ATM90E32AS"
   npx -y @jlcpcb/cli@0.4.0 info --json C177153
   npx -y @jlcpcb/cli@0.4.0 install C177153 -p <工程目录> --with-3d -y --json
   ```

| 坑 | 说明 |
|---|---|
| **EasyEDA 接口有 IP 级限流** | 连续约 **20 次**请求后 CloudFront 返回 **403**，持续十几分钟。`retryable:true` 但立刻重试无效，只能等。批量拉库要分批 + 退避（easyeda2kicad 加 `--use-cache`） |
| **生成的 `sym-lib-table` 只注册 1 个文件**（@jlcpcb/cli） | CLI 把符号拆成十几个 `.kicad_sym`，却只往 `sym-lib-table` 写一条。**拉完必须重写 sym-lib-table，把每个文件都注册上** |
| **符号名会被加 `_C<编号>` 后缀** | `SS34` → `SS34_C8678`，点号变下划线（`KF128-5.08-3P` → `KF128-5_08-3P`）。**代码里不要硬写型号名，先扫一遍库列出真实名字** |
| **所有引脚类型都是 `unspecified`** | ERC 对这些器件形同虚设，反过来还对每条正常连接刷 `pin_to_pin`。**能确定的改成 `passive`**（只改类型不动坐标） |
| **符号的引脚名可能是错的** | 实测 16.384MHz **无源晶体**的符号写着 `1=OE# / 3=OUT`——那是拿**有源晶振**模板生成的。**凡是引脚名可疑或为空的，回数据手册核对** |
| **多行/紧凑混排格式** | 按行 grep 会静默返回空。用 `scripts/kisexp.py` 解析，或用 SKILL 规则 00c 里那两条验证过的正则 |

4. **导入后逐项验证**：`python3 scripts/fp_compare.py <封装>` —— 实测间距、所有的孔（PTH/槽/NPTH/封装内 Edge.Cuts）、
   courtyard、极性丝印左右是否对称、3D 模型。两个候选封装直接 `fp_compare.py A B` 逐焊盘比。
5. 料号写进符号 `LCSC` 字段；工程库表（工程目录下 `fp-lib-table`/`sym-lib-table`）注册，**不要改全局库表**。

## 3. 用 Python 生成 KiCad 原理图（2026-09-06 实战，ATM90E32AS 计量板）

**场景**：从零画一张有几十个器件的原理图，而且要求"每一条连接都可断言"。
手画无法验证，SKiDL 只出网表不出图。**直接生成 `.kicad_sch` S-表达式是可行的**，
且一旦跑通就能把 ERC + 网表断言当测试套件用。

### `.kicad_sch` 生成的五个硬坑

1. **`lib_symbols` 段必须内嵌符号定义的原样字节。**
   只把最外层 `(symbol "NAME"` 改成 `(symbol "LIB:NAME"`，**内部子单元名（`R_0_1` 这种）一个字都不能动**，
   改了 KiCad 找不到子单元，图形全空。

2. **引脚的 `(at x y a)` 就是电气连接点本身**，不要再加 `length`。
   `a` 是引脚线从该点伸向本体的方向。**库坐标 y 向上、图纸坐标 y 向下**，变换时必须翻 y；**先旋转、后镜像**
   （`scripts/sch_conn.py` 的 `xform()`，已在 StickHub 69 个镜像+旋转符号上实测 0 个孤立引脚）：
   ```python
   dx, dy = px, -py                       # 库 -> 图纸方向
   if   rot==90:  dx, dy =  dy, -dx
   elif rot==180: dx, dy = -dx, -dy
   elif rot==270: dx, dy = -dy,  dx
   if mirror=='x': dy = -dy               # (mirror x)
   if mirror=='y': dx = -dx               # (mirror y)
   return (X + dx, Y + dy)
   ```

3. **⚠️ 器件属性的位置是绝对坐标，角度却是相对器件的。**
   器件转 90°，位号和值会跟着转成竖排。要让文字始终水平，**字段角度必须写 `(-rot) % 360`**。
   （这条只能靠渲染 PDF 目视发现，网表和 ERC 都不会报。）

4. **文字偏移量要按符号的「引脚盒 ∪ 图形盒」算，不能用固定值。**
   2.54mm 对 0402 电阻够用，对端子/压敏电阻这类**图形比引脚跨距宽**的符号就压在本体上了。
   图形盒要从符号定义里的 `rectangle` / `polyline` / `circle` / `arc` 算。

5. **`#PWR*` 电源符号的位号必须隐藏**（KiCad 惯例），否则满图都是 `#PWR01` 噪音。
   另外实测确认：**电源符号的网络名由它的 Value 字段决定**——
   所以可以用 `power:GNDPWR` 图形 + Value `"GND_M"` 画出"和安全地视觉上区分得开的市电地"。

### 层次图（多分图）的实例路径

子图里**每个器件的 `instances` 路径必须是 `/<根图纸uuid>/<根图里该子图元的uuid>`**。
写成子图自己的 uuid，KiCad 认不出该器件属于这张图，**网表里位号会丢**。

推论：**子图必须在根图纸建好之后再写盘**，或者事后对生成的文件做文本改写：
```python
re.sub(r'\(path "([^"]*)"(\s*\n\s*)\(reference "', repl, txt)   # 用 (reference 做锚点
re.sub(r'\n\t\(sheet_instances\n(?:.*\n)*?\t\)', "", txt)        # 子图不该有 sheet_instances
```
跨图连接用**全局标签**最省事（不用维护 sheet pin）。

### 网表解析

- `--format kicadsexpr` 出的是**多行缩进**的 s-表达式，**按行写正则会全部漏读**——必须真的做括号配对（`kisexp.py`）。
- 更省事的是 `--format kicadxml`，标准 XML 解析即可（`sch_conn.py`/`bomdiff.py` 用它）。
- **局部标签在网表里带图纸路径前缀**（`/MID`、`/sheet1/FOO`），要归一化；名字里的 `/` 在 `.kicad_sch` 里写作 `{slash}`。
- 悬空脚在网表里是单节点网络 `unconnected-(R1-Pad1)`；放了「无连接」标志的脚 `pintype` 带 `+no_connect`。

### ERC 的判读陷阱

- **对单张子图跑 ERC 会刷出一堆假警告**（`footprint_link_issues` / `lib_symbol_issues`）——独立文件不加载工程库表；
  新容器没配全局库表时根图也会刷。实测同一块板：子图 1 错 39 警告，**根图纸只有 1 错 8 警告**。**只认根图纸的结果**，
  且把库链接类单独列、不与连通性混看。
- `power_pin_not_driven` 要在每条电源网络上放 `power:PWR_FLAG` 才消（`sch_conn.py` 把 PWR_FLAG 当旗标、不当网络名）。
- ERC JSON 的 `pos` 坐标单位看 `coordinate_units` 字段，别想当然当 mm。

### 把 ERC + 网表断言当测试套件（硬件版 TDD）

| 软件 | 硬件对应 |
|---|---|
| `pytest` | `python3 scripts/check_netlist.py`（项目自写断言） |
| 断言 | "U1 的 AVDD 脚必须在网络 3V3_M 上" |
| 测试先红 | 断言脚本先写完，此时图还没画，全 FAIL |
| 集成测试 | `kicad-cli sch erc` + `sch_conn.py` |

**关键纪律：读网表的代码和生成图纸的代码必须是两份独立实现。**
用同一份代码读写，生成器算错的连接会被校验器用同样的错算法判成对的。

值得写的断言（都实测抓到过东西）：
- **电阻链是不是真串联**：沿链逐颗走，每颗必须和上一颗共享一个网络，且中间网络个数正确、互不重名（重名 = 画成了并联）
- **隔离带完整性**：安全侧网络集合 ∩ 市电侧网络集合，只允许隔离器和隔离电源出现在交集里
- **去耦完备性**：每个 IC 的每个电源脚，所在网络上必须挂着电容
- **手册强制接地脚**（如 M90E32AS 的 TEST / IC 脚）逐个断言

## 4. Freerouting 自动布线链（DSN/SES 往返）

```bash
kicad-python scripts/dsn_io.py export board.kicad_pcb board.dsn [--strip-tracks] [--strip-zones]
freerouting -de board.dsn -do board.ses -mp 20          # 无头：java -jar freerouting.jar --gui.enabled=false -de … -do …
kicad-python scripts/dsn_io.py import board.kicad_pcb board.ses routed.kicad_pcb
python3 scripts/drc_report.py routed.kicad_pcb && kicad-python scripts/pcb_conn.py routed.kicad_pcb
```
底层是 `pcbnew.ExportSpecctraDSN(board, path)` / `pcbnew.ImportSpecctraSES(board, path)`；
GUI：「文件 → 导出 → 无栅格自动布线器 DSN…」/「文件 → 导入 → Specctra 会话…」。
2026-09-26 实测（Freerouting 2.4.1 / OpenJDK 25）：pic_programmer 去走线去覆铜 → 9.5s 布完 → 导回 361 段 → 未连接 0。
⚠ Freerouting 在 chroot 外跑（要 Java），pcbnew 两端在 kicad-python 里跑，所以拆成三步，不要写成一个进程。

- **⚠️ DSN 规则来自旁边的同名 .kicad_pro**：把板子拷到别处导 DSN，没有配套工程文件 → 落回默认 0.2/0.2 规则 →
  Freerouting 全板报违例（实测 1472 条）+ 把既有连接判非法。**拷板必拷 .kicad_pro（同名）。**
- **⚠️ 同名封装大坑**：DSN 按封装名共享 image 定义。若 `.kicad_pcb` 里同名封装实例几何不同（例如把旋转烤进焊盘偏移的逐实例封装），
  Freerouting 用第一个实例的焊盘位置布所有同名件 → 180° 件全部接反（成对网络互换短路）。**封装名必须每实例一致几何**。
- **⚠️ zone=plane**：板上有 zone 时 DSN 导出为 plane，Freerouting 视该网络为已连不布线，也不避让；导回后重填 zone
  常被新走线切碎或与新走线冲突（实测 3 条 clearance + 1 条 shorting）。要让地网走线化：**布线前删 zone（`--strip-zones`），导回 SES 后再恢复 zone 重填**。
- **同封装同号焊盘（跳线/端子/变压器常见）是 DSN 隐形盘坑**：freerouting 只认其一，另一个被当空地碾过 →
  DRC 报短路/未连全部聚焦这些盘。生成 DSN 前给重号盘重编号（如 1→1A/1B），或事后定点修。
- **DSN 往返有损，别拿 Freerouting 反复优化已布通的 KiCad 板**：KiCad 走线充满 T 型接点，Freerouting 只认端点相接 →
  导入即报幻影"未布网络"，自动补冗余线添乱。优化轮只适合"从 DSN 出发一次成型"。
- `-mp` 只是自动布线 pass 上限，优化器遍数无 CLI 开关；`-us global` 在无头模式下几乎不起作用。
- 结果基准：EG8013 小板 105 件/78 网络/4 层，freerouting 三轮后 418/419 连接布通，最后一根需交互式推挤
  （口袋内通孔被内层线挡、B 层出口被焊盘排封死，属"不动他网无解"类）。
- **Java 探测**：只认真跑一次 `java -version` / `freerouting --help`；`which java` 有输出不算（`/usr/bin/java` 可能是空壳存根，keg-only JDK 不进 PATH）。

## 5. 去重叠的铁律（用户纠错后补，2026-08-26）

- **结构件绝不允许被去重叠求解器移动**：插座/端子/排针（尤其成对插座如 P1A/P1B——相对间距=配合小板）、模块座、
  散热器上的 TO-220 排、磁件、保险、继电器、电池端子。锚定清单要在求解前列全（本例 33 件），求解后加"结构件位移==0"硬断言。
  KiCad 里对结构件先「锁定」。
- 结构件之间的原生重叠（P1A-P1B、P2/P3-K2）列豁免清单：不强解、DRC 闸门按豁免口径放行。
- 两阶段必收敛：力弛豫（每轮力平均化防振荡）+ 对卡死件螺旋搜索就近搬迁（0.25mm 步进、小件优先、贪心提交）。
  本例 291 件中 143 件微移（最大 8.4mm）后焊盘异网间隙全部 ≥ 0.25mm。
- **窗口内障碍物排查勿用"端点在窗口内"过滤**——长线两端都在窗外会漏掉，要用线段-窗口相交或全量收集。

## 6. ⭐ 自写 A* 布线引擎的三处模型根因（2026-08-27，实测定位，务必牢记）

自写栅格 A* 若"布通了但 DRC 爆炸"，几乎一定是障碍模型错，不是运气差。三处已修：
1. **`obs = 全部铜 & ~本网铜` 会擦掉邻网实体铜**。本网铜的*间距光环*常盖住邻网的铜；一做减法，邻网的铜就从障碍图里消失 →
   成百上千 shorting_items。正确做法：障碍 = **外网几何的并集**（`nonjob | ⋃_{Y≠X} own[Y]`），绝不用减法。按网缓存该并集。
2. **过孔可放位置用"圆盘膨胀"近似，对角方向不足**。`dilate(obs, 2格)` 在 45° 只够到 0.141mm，而需要 0.205mm → 恰好差出 DRC 报的 ~0.05mm。
   正确做法：`ndimage.distance_transform_edt(~obs) <= 阈值`，各向同性。
3. **栅格化本身还有半格误差**。阈值要**再加一整格**余量。（走线不受此影响；只有"先栅格化再量距离"的两步路径会累积。）

另：**圆形/椭圆焊盘必须按胶囊建模**（两端半圆 + 中间矩形），用外接矩形会刷出一片假间距违规（实测 18 处全是假的）；
焊盘旋转字段别读错（读错一次把 2.3×0.63mm 的栅极焊盘建成 0.63×2.3mm，过孔放进了焊盘里）——**布线器的结果一律要过独立校验器再落盘**。
起终点必须精确落在焊盘中心/过孔坐标（网格吸附会偏 0.02-0.04mm，KiCad 判连通没问题，但 DSN 再导出时 Freerouting 判未连）。

## 7. ⭐ 布线流程的硬教训（2026-08-27 起累积）

- **KiCad 的 ratsnest 才是连通性真值**（`pcb_conn.py` 与之对账）。自写几何聚类没有覆铜模型时，会把靠铜皮连通的网判成断开，
  引擎去啃不存在的缺口。任务列表必须用 DRC 的 `unconnected_items` 过滤。
- **布线次序按"逃逸难度"排，不是按连接距离排**：连接器焊盘 → 元件焊盘 → 从已有铜起步。连接器 2.54mm 阵列之间只有 ~0.5mm 逃逸通道，
  排在最后必然被占满。**两端**都要看。
- **拆墙必须让被困者先布**，否则墙的主人会沿最优路径把同一道墙原样画回去。"数字一模一样"本身就是没改到关键路径的信号。
- **容量受限区贪心布线无解**：N 个网抢 M<N 条通道，任何优先级排列只是把失败在网之间搬运。只能整块清空重排或改布局。
- **长走线的 DRC 坐标是它的起点，不是最近点**。照那个方向推过孔会南辕北辙，必须自己算最近点。
- **落盘脚本要分别统计走线和过孔**：只统计走线会打印"applied 0"却仍写入过孔 → 重复应用 → 同位置叠两个过孔 → 连锁短路。每次布线前先删结果文件。
- **删悬空段要"纯修剪"**：只删不布，反复到收敛（本例连锁削掉 102 段），之后再统一补线。`pcb_conn.py` 列出悬空端点；
  KiCad DRC 对应 `track_dangling`（注意：自写判据把"端点落在同网另一条线的铜宽内"算连上，比 KiCad 宽松，两者不一致时逐条看）。
- 过孔微移是修擦边间距的利器（0.1mm 就能从违规变合规），但**必须同时移动连在过孔上的走线端点**。
- **用线段归一化键 (net, layer, minx, miny, maxx, maxy) 做比对可以，绝不能用它反向重建线段**：包围盒两条对角线共享同一键，
  会把下行斜线翻成上行反对角线横穿别的网络。补建段必须从源几何取原始坐标。
- **空板对照实验**（判断"该不该为布线去改布局"）：1mil 级栅格单层迷宫布线器，实板跑 + 删光除焊盘外所有铜再跑；
  空板成功实板失败 = 挡路的是别的网络的铜，改布局没用；都失败 = 几何固有限制，改布局也没用。
- **重跑布线闭环是赌博**：一份 40/40 的结果是多轮协商收敛出来的，原样重跑只有 39/40、加障碍重跑 8 次最好 38/40 → 局部问题定点修补。
- **尺寸压到极限时先改设计规则再怪布线器**：8/8mil 只有 88.6%，6/6mil 直接 100%。**先回读再动手**，常常只需改一条。
- **引脚排间放不下标准过孔时用最小过孔换层**：Type-C 两排引脚间只有 0.8mm，0.6/0.3 过孔放不下，0.45/0.3 放得下，省掉整条绕行环。
- **KiCad 长度报告会把重叠/重复段算两遍**：按「同层同宽同直线」做区间并集才是物理铜长（实测 60.34 vs 55.54mm），先清理再读。

## 8. 嘉立创导出（板厂侧，不涉及任何 EDA）

`python3 scripts/jlc_fab.py board.kicad_pcb --out fab/` 一次出：
- `fab/gerber/`：铜层 + F/B.Paste + F/B.Silkscreen + F/B.Mask + Edge.Cuts（Protel 扩展名），Excellon PTH/NPTH 分开 + 钻孔报告；
- `<板名>-GERBER.zip`（上传用，之后必须 `gerber_check.py` 读这一份）；
- `<板名>-BOM-JLC.csv`：`Comment,Designator,Footprint,LCSC Part #`，从原理图 `LCSC` 字段出；
- `<板名>-CPL-JLC.csv`：`Designator,Mid X,Mid Y,Layer,Rotation`。
自检：料号必须 `C`+数字；BOM 位号 ⊇ CPL 位号；封装角度全 0 报警。
实测（RoyalBlue54L，8 层）：18 个文件、45 个贴片件、48 个 BOM 位号，抓出 `J6` 料号为空（PCB 侧却有 `C5213747`——两侧不同步）。
