> 2026-09-26 改版：用户规定只用 KiCad。快照从「EDA 面板/CDP 导出」改为「冻结的 KiCad 工程 + kicad-cli/脚本产物」，其余不变。

# 五维并行审查任务书（规则 00d 的执行细则）

规则 00d 规定了**什么时候**跑；本文规定**怎么跑**。两个闸口各一套泳道。

---

## 0. 铁律：并行只读，串行写

这三条是整套并行审查能成立的前提，破一条就退化成"五个代理互相踩"。

### ① 泳道代理一律只读

不许打开并保存 `.kicad_sch`/`.kicad_pcb`、不许跑任何写动作的脚本（`dsn_io.py import`、`--save-board`、改字段的脚本）、
不许 `SendMessage` 直接指挥画图代理。
发现的问题**只写进报告**，回主线程串行修。

### ② 泳道的输入是**冻结的 KiCad 快照**，不是活工程

⚠️ **绝对不要让五条泳道各自去读正在被编辑的工程目录。** 画图代理（或用户开着的 KiCad GUI）
任何一次保存都会让泳道读到另一版数据；A 读的是改前的 `.kicad_sch`、B 读的是改后的 `.kicad_pcb`，
**错得没有报错**——你会得到五份看着很像的、互相矛盾的报告。

主线程（或 `tool` 角色子代理，见 models.toml）先把快照做出来、冻结，再发车：

```
review/<gate>-<YYYYMMDD-HHMM>/     # 目录名带时间戳，做完不再改动（可 chmod -R a-w）
  src/                              # 工程文件原样拷贝：*.kicad_pro *.kicad_sch *.kicad_pcb 工程库表与工程库
  SHA256SUMS                        # sha256sum src/* —— 泳道开工前先校验，对不上就是快照被动过
```
⚠ 泳道要复跑 kicad-cli 时，**在快照目录的拷贝上跑**（kicad-cli 读工程同名 `.kicad_pro` 的规则，所以要整目录拷），
输出写到自己的临时目录，不写回快照。

### ③ 改完必须重出快照，不许在旧快照上复议

修一条 P0 会挪动网表/坐标，其他泳道的结论随之失效。
串行修 → 重出快照 → **重跑受影响的泳道**，直到 P0=P1=0。

---

## 1. 闸口 A：原理图导出后（进 PCB 之前）

### 快照准备（串行，可派 `tool` 角色）

| 产物 | 怎么来 | 给谁用 |
|---|---|---|
| `src/` + `SHA256SUMS` | 冻结的 `.kicad_pro`/`.kicad_sch`（全部子图）/工程库 | 全部泳道 |
| `erc.json` | `kicad-cli sch erc --format json --severity-all -o erc.json <根图>` | A1（**权威的引脚悬空判据**，见规则 00 ⓪） |
| `netlist.xml` | `kicad-cli sch export netlist --format kicadxml -o netlist.xml <根图>` | A1 A2 A5 |
| `sch_conn.txt` / `sch_conn.json` | `python3 sch_conn.py <根图> --erc erc.json --netlist netlist.xml --json sch_conn.json` | A1（悬空、两脚件断一端、死头配对、同网多名） |
| `pcb-pads.txt`（已有 PCB 时） | `kicad-python` 导出每个焊盘的 `位号.焊盘号 → 网络`（空或 `unconnected-*` 即断） | A1 交叉验证 |
| `bom.csv` | `kicad-cli sch export bom --fields 'Value,Reference,Footprint,LCSC' …` | A3 |
| `sch.pdf` | `kicad-cli sch export pdf -o sch.pdf <根图>` | 全部泳道（目视） |
| `req.md` | **用户原始需求原文** | A2 A4 A5（按需求核，不是按图核图） |

⚠️ ERC 没归零的图不送审，别浪费一轮（沿用规则 00c）。

### 五条泳道

| 泳道 | 审什么 | 主要依据 |
|---|---|---|
| **A1 连通性** | 引脚悬空死头、单点网络、同一网络两个名字、标签/电源符号失配 | `erc.json` > `netlist.xml` / `pcb-pads.txt` > `sch_conn.py` 的几何判据（**优先级不可颠倒**，见规则 00 ⓪） |
| **A2 电源与去耦** | 电源树完整性、每颗 IC 去耦完备（规则 00 ①）、DCDC/LDO 压差与裕量、上电时序、各支路载流预算 | 手册 + 算式 |
| **A3 器件与额定值** | 符号↔封装匹配、耐压/耐流/功率/温度裕量、极性与方向、精度等级、`LCSC` 料号有效性、**嘉立创库存**与基础/扩展库 | `bom.csv` + 手册 + `fp_compare.py` |
| **A4 功能与手册** | 逐 IC 对照典型应用电路、未用脚处理、上下拉、复位/启动脚配置、时钟与晶振负载电容 | 手册（逐页码） |
| **A5 接口与保护** | ESD/限流/反接保护、连接器针脚定义、电平匹配、隔离域跨越、对外接口的异常输入 | `req.md` + 网表 |

**A1 不是新增检查**——它就是把规则 00 ⓪/⓪b 整段交给一条泳道执行。任务书里直接贴规则 00 原文。

### 第 6 条泳道：换厂商模型的全局复核（规则 00c，同时发车）

换厂商模型的独立复核**不要等五维跑完再串行做**，它就是第 6 条泳道，同时发。
跑法、提示词要求、谁画谁审（以规则 00c 的最新改令为准）见规则 00c，不重复。

---

## 2. 闸口 B：PCB 制造文件导出后（下单之前）

### 快照准备（串行，可派 `tool` 角色）

```bash
S=<skill>/scripts; R=review/B-<时间戳>        # 需要 pcbnew 的脚本放在 kicad-python 能访问的路径（/home/user 或 /tmp）
cp -r <工程>/{*.kicad_pro,*.kicad_sch,*.kicad_pcb,*-lib-table,lib} $R/src/ && (cd $R && sha256sum src/* > SHA256SUMS)
python3 $S/drc_report.py $R/src/board.kicad_pcb --json-out $R/drc.json   > $R/drc.txt    # refill + parity + ignore 点名
kicad-python $S/pcb_conn.py  $R/src/board.kicad_pcb --json $R/conn.json  > $R/conn.txt   # 自写并查集 vs ratsnest
kicad-python $S/pcb_check.py $R/src/board.kicad_pcb --json $R/check.json > $R/check.txt  # 干涉/丝印/板边/via-in-pad/电感/孔
kicad-cli sch export netlist --format kicadxml -o $R/netlist.xml $R/src/<根图>.kicad_sch
python3 $S/bomdiff.py $R/netlist.xml $R/src/board.kicad_pcb              > $R/bomdiff.txt # 两侧一致
unzip -d $R/gerber/ <下单用的那个 zip> && python3 $S/gerber_check.py <下单用的那个 zip> > $R/gerber.txt
cp <下单用的 BOM/CPL csv> $R/
kicad-cli pcb export svg -l F.Cu,F.Silkscreen,Edge.Cuts -o $R/top.svg $R/src/board.kicad_pcb   # 目视
```
⚠ `drc_report.py` 带 `--refill-zones` 但不 `--save-board`，不会改快照里的板子。

⚠️ **送审的 Gerber 必须是准备提交的那一份**，不是"再导一次应该一样"的另一份。
规则 2b 的教训：导出通道不同，内容会不同。

### 五条泳道

| 泳道 | 审什么 | 主要依据 |
|---|---|---|
| **B1 制造 / DFM** | 直接读钻孔表和光圈表、最小线宽/孔径/环宽、阻焊桥、拼板与工艺边、泪滴、文件名逐字核对 | 解开的 Gerber + `gerber.txt`（规则 2b ①④⑧⑨） |
| **B2 电源完整性** | 载流线宽、过孔载流与数量、铺铜连续性与孤岛、去耦电容到引脚的回路面积、地平面被信号线割裂、**电感下方避让** | `src/board.kicad_pcb`（kicad-python 只读分析）+ 叠层（规则 0a）+ `check.txt` ⑨ |
| **B3 信号完整性 / 回流** | 高速线参考平面完整、跨分割、差分对间距与等长、桩线、时钟包地、层变换处的回流过孔 | `src/board.kicad_pcb` + 规则 0c 的差分对规划 |
| **B4 热与机械** | 散热焊盘与热过孔、器件高度干涉、螺丝孔与板边间距、连接器插拔方向与开孔、**封装里的所有的孔** | `check.txt` ⑦⑩ + `fp_compare.py src/board.kicad_pcb:<位号>`（规则 0d ②③） |
| **B5 一致性** | `conn.txt` 两判据一致且未布通=0、`check.txt` 三项=0、DRC=0 且被 ignore 的项已逐条确认、parity=0、`bomdiff.txt`=0、位号丝印齐全且不压焊盘、极性标记 | 上面那批脚本输出 |

⚠️ B5 拿的是脚本结论，但**脚本本身不可信**（scripts/README.md 铁律一）。
B5 的任务书必须要求它对每个"=0"用第二个独立判据交叉验证（`pcb_conn` ↔ DRC unconnected、`pcb_check` ① ↔ DRC courtyards_overlap、
`pcb_check` ④ ↔ `gerber_check` ③），或指出无法验证。

---

## 3. 输出契约（两个闸口通用）

### 每条发现的固定格式

```
[P0|P1|P2] <位号+引脚 / 网络名 / Gerber 文件:行 / 坐标>
现象：……
依据：<数据手册 页码 | 算式 | 规则编号 | 脚本输出行>
建议：……
```

- **没有依据的意见不采**（沿用规则 00c）。
- 分档沿用：`P0 不能投板 / P1 必须改 / P2 建议`。

### 必须同时交「已核对无问题」清单

⚠️ 只报问题的报告**无法区分"查了没事"和"根本没查"**。
每条泳道必须附一份覆盖清单：核过哪些器件/网络/文件、哪些因为拿不到手册或数据没核到。
**没交覆盖清单的报告按未完成处理，重跑。**

### 报告落盘

```
review/<gate>-<时间戳>/A1-连通性.md   …  A5-接口保护.md   <复核模型>-全局.md
review/<gate>-<时间戳>/MERGED.md                        # 主线程汇总
```

---

## 4. 汇总与收敛（主线程做，不派）

1. **去重**：同一根因会被多条泳道重复报（去耦缺失 A2 和 A4 都会报），按根因合并，保留证据最强的那条依据。
2. **冲突不裁决**：两条泳道结论打架时不判谁对，把双方依据并列交用户（沿用规则 00c）。
3. **串行修**：P0/P1 逐条派回**原来画图的子代理**（`SendMessage` 到它的 agent id，上下文还在）。一次一条，改完重出快照。
4. **重跑**：重跑受影响的泳道，直到 P0=P1=0 才过闸。
5. **P2 汇总给用户定夺，不擅自改。**

---

## 5. 派车须知

### 模型

- 快照准备（跑脚本、解压、导出、搬文件）→ **haiku**。
- 五条泳道 + 第 6 条泳道 → **当时可用的最高级模型**。审查干的正是"判断这个论证成不成立"，属于规则 00c 里明确不能省的那一类。

### 任务书必须可接续

长审查会被用量耗尽掐断（HTTP 429）。每条泳道的任务书里要写清：
报告落盘路径、**边查边写不要攒到最后一次性输出**、续跑的代理先读已有报告接着写。
派接续代理时**显式指定 `model:`**（子代理不会自动回退）。

### 一次发五条，不要分批

分批的坏处是：你按 A1 的结论改完线，A3 才告诉你那颗料要换、封装也得跟着换，前面的修改白做。
五条泳道读的是**同一份不变的快照**，没有任何冲突可能，就该一起发。

---

## 6. 红旗（出现即停）

- 「先只跑连通性，其他等改完再说」→ 违反 §5，白改
- 「让泳道代理顺手把问题改了」→ 违反 §0①
- 「五个代理各自读活工程目录 / 开着 GUI 的工程」→ 违反 §0②，会拿到静默错误的数据
- 「快照 SHA256SUMS 对不上还接着审」→ 违反 §0②
- 「在旧快照上复议」→ 违反 §0③
- 「泳道说没问题」但没给覆盖清单 → 按未完成处理
- 「这次改动很小，跳过闸口」→ 规则 00d 没有"改动很小"这一档
