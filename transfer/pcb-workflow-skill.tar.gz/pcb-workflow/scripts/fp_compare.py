#!/usr/bin/env python3
"""封装逐焊盘核对 / 两个封装逐焊盘比对 —— 规则 0b（换料验封装）、0d（所有的孔）、取库必做四条。

    python3 fp_compare.py <封装>                 # 单个：列焊盘、实测间距、孔清单、丝印极性线索
    python3 fp_compare.py <封装A> <封装B>        # 两个：按焊盘号逐个比坐标/尺寸/孔

<封装> 可以是：
  X.kicad_mod                          库里的单个封装文件（KiCad 官方库 / easyeda2kicad 生成的都行）
  Lib.pretty/NAME                      等价于 Lib.pretty/NAME.kicad_mod
  board.kicad_pcb:R12                  板子上某个位号的封装实例（焊盘坐标是封装局部坐标）

为什么要“实测坐标算间距”：焊盘个数一样不代表是同一个系列（JST XH 2.50 vs 2.54 排针，
3P 对 3P，数量校验完全挡不住）。本脚本用真正的 S-表达式解析，不会像按行 grep 那样
在 easyeda2kicad 的多行/紧凑混排格式上静默返回空。纯标准库。
"""
import argparse, collections, math, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kisexp as S  # noqa: E402


def load_fp(spec):
    if ':' in spec and spec.split(':')[0].endswith('.kicad_pcb'):
        path, ref = spec.rsplit(':', 1)
        for fp in S.findall(S.load(path), 'footprint'):
            if S.props(fp).get('Reference') == ref:
                return fp, f'{ref}（{fp[1]}）'
        raise SystemExit(f'{path} 里没有位号 {ref}')
    if spec.endswith('.pretty') is False and os.path.isdir(os.path.dirname(spec)) and not spec.endswith('.kicad_mod') \
            and os.path.exists(spec + '.kicad_mod'):
        spec += '.kicad_mod'
    t = S.load(spec)
    if t[0] not in ('footprint', 'module'):
        raise SystemExit(f'{spec} 不是封装文件')
    return t, t[1]


def pads_of(fp):
    out = []
    fp_rot = (S.at(fp) or (0, 0, 0))[2]
    for p in S.findall(fp, 'pad'):
        num, typ, shape = p[1], p[2], p[3]
        x, y, r = S.at(p)
        sz = S.find(p, 'size')
        w, h = (float(sz[1]), float(sz[2])) if sz else (0, 0)
        dr = S.find(p, 'drill')
        drill = None
        if dr:
            vals = [v for v in dr[1:] if isinstance(v, str)]
            if vals and vals[0] == 'oval':
                nums = [float(v) for v in vals[1:3]]
                drill = ('oval', nums[0], nums[1] if len(nums) > 1 else nums[0])
            else:
                nums = [float(v) for v in vals if S._isnum(v)]
                drill = ('round', nums[0], nums[0]) if nums else None
        layers = S.find(p, 'layers')
        out.append(dict(num=num, type=typ, shape=shape, x=x, y=y, rot=(r - fp_rot) % 360, w=w, h=h, drill=drill,
                        layers=[l for l in (layers[1:] if layers else [])]))
    return out


def graphics(fp):
    g = collections.Counter()
    xs = collections.defaultdict(list)
    for kind in ('fp_line', 'fp_circle', 'fp_arc', 'fp_poly', 'fp_rect', 'fp_text'):
        for it in S.findall(fp, kind):
            lay = S.val(it, 'layer', 1, '')
            g[(lay, kind)] += 1
            for k in ('start', 'end', 'center', 'at'):
                n = S.find(it, k)
                if n:
                    xs[lay].append(float(n[1]))
    return g, xs


def report(fp, title):
    ps = pads_of(fp)
    print(f'\n=== {title}：焊盘 {len(ps)} 个 ===')
    for p in sorted(ps, key=lambda p: (len(p['num']), p['num'])):
        d = '' if not p['drill'] else (f"孔 {p['drill'][1]}" if p['drill'][0] == 'round' else f"槽 {p['drill'][1]}x{p['drill'][2]}")
        print(f"   {p['num'] or '(无号)':>5} {p['type']:13} {p['shape']:9} ({p['x']:8.3f},{p['y']:8.3f}) "
              f"{p['w']:.3f}x{p['h']:.3f} {d}")
    # 实测间距：同一行/列相邻焊盘的中心距
    num = [p for p in ps if p['num'] and p['type'] != 'np_thru_hole']
    pitches = collections.Counter()
    for axis in ('x', 'y'):
        other = 'y' if axis == 'x' else 'x'
        rows = collections.defaultdict(list)
        for p in num:
            rows[round(p[other], 2)].append(p[axis])
        for vs in rows.values():
            vs = sorted(set(round(v, 4) for v in vs))
            for a, b in zip(vs, vs[1:]):
                pitches[round(b - a, 3)] += 1
    print('   实测相邻焊盘中心距(mm)×次数：', dict(pitches.most_common(6)) or '—')
    # 所有的孔
    holes = collections.Counter()
    for p in ps:
        if p['type'] == 'np_thru_hole':
            holes['NPTH ' + (f"⌀{p['drill'][1]}" if p['drill'] and p['drill'][0] == 'round' else f"槽{p['drill'][1:]}")] += 1
        elif p['drill']:
            holes[('PTH ⌀%s' % p['drill'][1]) if p['drill'][0] == 'round' else f"PTH 槽 {p['drill'][1]}x{p['drill'][2]}"] += 1
    g, xs = graphics(fp)
    ec = sum(n for (l, _k), n in g.items() if l == 'Edge.Cuts')
    print('   孔：', dict(holes) or '无', ('；⚠ 封装内含 Edge.Cuts 图形 %d 个（挖槽/定位柱画成了板框）' % ec) if ec else '')
    smd_named_ep = [p['num'] for p in ps if p['drill'] and p['num'] and not p['num'].isdigit()]
    if smd_named_ep:
        print(f'   ⚠ 非数字编号却带孔的焊盘 {smd_named_ep}：安装脚/定位柱是通孔，布线时按双层实心障碍处理')
    sl = sum(n for (l, _k), n in g.items() if 'Silk' in l)
    cy = sum(n for (l, _k), n in g.items() if 'CrtYd' in l)
    fab = sum(n for (l, _k), n in g.items() if 'Fab' in l)
    asym = ''
    for l, v in xs.items():
        if 'Silk' in l and v:
            asym = '左右不对称（有方向标记）' if abs(max(v) + min(v)) > 0.05 else '左右对称（⚠ 若是有极性器件，检查 1 脚/极性标记）'
    print(f'   丝印图元 {sl}（{asym or "无"}），courtyard 图元 {cy}，fab 图元 {fab}' +
          ('  ⚠ 无 courtyard：干涉检查会退化成 bbox' if not cy else ''))
    m3 = S.find(fp, 'model')
    print('   3D 模型：', m3[1] if m3 else '无')
    return ps


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('a')
    ap.add_argument('b', nargs='?')
    ap.add_argument('--tol', type=float, default=0.01, help='坐标/尺寸容差 mm')
    x = ap.parse_args()
    fa, ta = load_fp(x.a)
    pa = report(fa, ta)
    if not x.b:
        return
    fb, tb = load_fp(x.b)
    pb = report(fb, tb)
    A = collections.defaultdict(list)
    B = collections.defaultdict(list)
    for p in pa:
        A[p['num']].append(p)
    for p in pb:
        B[p['num']].append(p)
    diff = []
    for k in sorted(set(A) | set(B), key=lambda s: (len(s), s)):
        if len(A[k]) != len(B[k]):
            diff.append(f'焊盘 {k!r}：A 有 {len(A[k])} 个，B 有 {len(B[k])} 个')
            continue
        for p, q in zip(sorted(A[k], key=lambda p: (p['x'], p['y'])), sorted(B[k], key=lambda p: (p['x'], p['y']))):
            if math.hypot(p['x'] - q['x'], p['y'] - q['y']) > x.tol:
                diff.append(f"焊盘 {k}：坐标 ({p['x']},{p['y']}) vs ({q['x']},{q['y']})")
            ws = sorted((p['w'], p['h'])), sorted((q['w'], q['h']))
            if abs(ws[0][0] - ws[1][0]) > x.tol or abs(ws[0][1] - ws[1][1]) > x.tol:
                diff.append(f"焊盘 {k}：尺寸 {p['w']}x{p['h']} vs {q['w']}x{q['h']}")
            if (p['drill'] or None) != (q['drill'] or None):
                diff.append(f"焊盘 {k}：孔 {p['drill']} vs {q['drill']}")
            if p['type'] != q['type']:
                diff.append(f"焊盘 {k}：类型 {p['type']} vs {q['type']}")
    print(f'\n=== 比对：差异 {len(diff)} 条 ===')
    for d in diff:
        print('   ' + d)
    print('   ⚠ 封装一致 ≠ 能换：还要比「引脚号 → 功能」（符号脚位定义），封装一样脚位不同 = 装上去短路，DRC 不报'
          if not diff else '   任何差异都不能直接换；要换就先改 PCB（规则 0b）')
    sys.exit(1 if diff else 0)


if __name__ == '__main__':
    main()
