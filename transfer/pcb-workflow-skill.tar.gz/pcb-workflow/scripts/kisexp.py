"""极简 KiCad S-表达式解析器（.kicad_sch / .kicad_pcb / .kicad_mod / .kicad_sym 通用）。

为什么不用正则按行 grep：KiCad 10 与 easyeda2kicad 生成的文件是**多行缩进/紧凑混排**，
按行正则会静默返回空（实测踩过，误以为“库是空的”）。这里做真正的括号配对。

纯标准库，系统 python3 与 kicad-python 都能 import。
"""
import re

_TOK = re.compile(r'\s*(?:(\()|(\))|"((?:[^"\\]|\\.)*)"|([^\s()"]+))', re.S)


def _unescape(s):
    return s.replace('\\"', '"').replace('\\n', '\n').replace('\\\\', '\\')


def parse(text):
    """返回嵌套 list；原子与字符串都是 str。"""
    stack = [[]]
    for m in _TOK.finditer(text):
        o, c, s, a = m.groups()
        if o:
            stack.append([])
        elif c:
            x = stack.pop()
            stack[-1].append(x)
        elif s is not None:
            stack[-1].append(_unescape(s))
        elif a is not None:
            stack[-1].append(a)
    if len(stack) != 1 or not stack[0]:
        raise ValueError('括号不配对或文件为空')
    return stack[0][0]


def load(path):
    with open(path, encoding='utf-8') as f:
        return parse(f.read())


def is_node(x, name=None):
    return isinstance(x, list) and x and (name is None or x[0] == name)


def find(node, name):
    """第一个名为 name 的直接子节点。"""
    for x in node[1:]:
        if is_node(x, name):
            return x
    return None


def findall(node, name):
    return [x for x in node[1:] if is_node(x, name)]


def walk(node, name):
    """递归找出所有名为 name 的节点（深度优先）。"""
    out = []
    st = [node]
    while st:
        n = st.pop()
        if not isinstance(n, list):
            continue
        if n and n[0] == name:
            out.append(n)
        st.extend(reversed(n[1:]))
    return out


def val(node, name, idx=1, default=None):
    """(name v1 v2 ...) 的第 idx 个值。"""
    n = find(node, name) if node else None
    if n is None or len(n) <= idx:
        return default
    return n[idx]


def at(node):
    """(at x y [rot]) -> (x, y, rot)。"""
    a = find(node, 'at')
    if a is None:
        return None
    x, y = float(a[1]), float(a[2])
    r = float(a[3]) if len(a) > 3 and _isnum(a[3]) else 0.0
    return x, y, r


def props(node):
    """(property "Key" "Val" ...) -> {Key: Val}；兼容老格式 (fp_text reference "R1")。"""
    d = {}
    for p in findall(node, 'property'):
        if len(p) >= 3 and isinstance(p[1], str) and isinstance(p[2], str):
            d[p[1]] = p[2]
    for t in findall(node, 'fp_text'):
        if len(t) >= 3 and t[1] in ('reference', 'value'):
            d.setdefault('Reference' if t[1] == 'reference' else 'Value', t[2])
    return d


def _isnum(s):
    try:
        float(s)
        return True
    except (TypeError, ValueError):
        return False
