#!/usr/bin/env python3
"""从 KiCad 工程一次性出嘉立创下单文件（Gerber+钻孔 zip、BOM、CPL）并做基本自检 —— 规则 2b、0b。

    python3 jlc_fab.py <board.kicad_pcb> [--sch root.kicad_sch] [--out fab/] [--lcsc-field LCSC]

需要 kicad-cli（chroot 版只能访问 /home/user 与 /tmp）。纯标准库。
产物（都在 --out 下）：
  gerber/            Gerber（Protel 扩展名）+ Excellon 钻孔（PTH/NPTH 分开）+ 钻孔报告
  <板名>-GERBER.zip  上传用 zip —— 之后必须跑 gerber_check.py 读这一份本身
  <板名>-BOM-JLC.csv Comment, Designator, Footprint, LCSC Part #（按 值+封装+料号 归组，位号不压缩成区间）
  <板名>-CPL-JLC.csv Designator, Mid X, Mid Y, Layer, Rotation（mm）
自检：BOM 料号必须 C+数字；BOM 位号集合 = CPL 位号集合（贴片件）；封装角度全 0 报警。
⚠ 嘉立创贴片角度与 KiCad 库的 0° 定义对部分封装不一致 —— 下单页「贴片预览」里逐颗看极性件，
  不对就在 CPL 里改 Rotation（或给封装加 JLC 旋转偏移字段），不要默认“导出即正确”。
"""
import argparse, csv, glob, os, re, subprocess, sys, zipfile

JLC_LAYERS = ['F.Paste', 'B.Paste', 'F.Silkscreen', 'B.Silkscreen', 'F.Mask', 'B.Mask', 'Edge.Cuts']


def cli(*args):
    r = subprocess.run(['kicad-cli', *args], capture_output=True, text=True)
    if r.returncode != 0:
        sys.stderr.write(r.stdout + r.stderr)
        raise SystemExit('kicad-cli 失败: ' + ' '.join(args))
    return r.stdout


def copper_layers(pcb):
    txt = open(pcb, encoding='utf-8').read()
    m = re.search(r'\(layers\s*(.*?)\n\t\)', txt, re.S)
    names = re.findall(r'"((?:F|B|In\d+)\.Cu)"', m.group(1) if m else txt[:20000])
    order = ['F.Cu'] + sorted({n for n in names if n.startswith('In')}, key=lambda s: int(s[2:-3])) + ['B.Cu']
    return [n for n in order if n in names]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('pcb')
    ap.add_argument('--sch')
    ap.add_argument('--out', default='fab')
    ap.add_argument('--lcsc-field', default='LCSC')
    a = ap.parse_args()
    name = os.path.splitext(os.path.basename(a.pcb))[0]
    sch = a.sch or os.path.splitext(a.pcb)[0] + '.kicad_sch'
    gd = os.path.join(a.out, 'gerber')
    os.makedirs(gd, exist_ok=True)
    for f in glob.glob(os.path.join(gd, '*')):
        os.remove(f)  # 旧文件混进 zip 是下错板的第一步

    layers = copper_layers(a.pcb) + JLC_LAYERS
    cli('pcb', 'export', 'gerbers', '--layers', ','.join(layers), '--subtract-soldermask', '-o', gd + '/', a.pcb)
    cli('pcb', 'export', 'drill', '--excellon-separate-th', '--generate-report', '--report-path',
        os.path.join(gd, name + '-drill-report.txt'), '-u', 'mm', '-o', gd + '/', a.pcb)
    zp = os.path.join(a.out, f'{name}-GERBER.zip')
    with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(glob.glob(os.path.join(gd, '*'))):
            if not f.endswith('-drill-report.txt'):
                z.write(f, os.path.basename(f))
    print(f'Gerber zip: {zp}（{len(z.namelist())} 个文件，铜层 {copper_layers(a.pcb)}）')

    bom = os.path.join(a.out, f'{name}-BOM-JLC.csv')
    if os.path.exists(sch):
        cli('sch', 'export', 'bom', '--fields', f'Value,Reference,Footprint,{a.lcsc_field}',
            '--labels', 'Comment,Designator,Footprint,LCSC Part #', '--group-by', f'Value,Footprint,{a.lcsc_field}',
            '--ref-range-delimiter', '', '--exclude-dnp', '-o', bom, sch)
    else:
        print(f'⚠ 找不到原理图 {sch}：BOM 必须从原理图出（原理图是 BOM 的源头，规则 0b）')
        bom = None

    pos = os.path.join(a.out, f'{name}-pos.csv')
    cli('pcb', 'export', 'pos', '--format', 'csv', '--units', 'mm', '--side', 'both', '--exclude-dnp',
        '--exclude-fp-th', '-o', pos, a.pcb)
    cpl = os.path.join(a.out, f'{name}-CPL-JLC.csv')
    rows = list(csv.DictReader(open(pos, encoding='utf-8')))
    with open(cpl, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['Designator', 'Mid X', 'Mid Y', 'Layer', 'Rotation'])
        for r in rows:
            w.writerow([r['Ref'], r['PosX'] + 'mm', r['PosY'] + 'mm', 'Top' if r['Side'].lower() == 'top' else 'Bottom',
                        r['Rot']])
    print(f'CPL: {cpl}（{len(rows)} 个贴片件）')

    errs = []
    rots = {float(r['Rot']) for r in rows}
    if len(rows) > 5 and rots == {0.0}:
        errs.append('CPL 角度全是 0：封装旋转被烘进了封装本体，有极性的件会全部贴反')
    if bom:
        brefs, badlc = set(), []
        for r in csv.DictReader(open(bom, encoding='utf-8')):
            refs = [x for x in re.split(r'[,\s]+', r['Designator']) if x]
            brefs |= set(refs)
            if not re.fullmatch(r'C\d+', r['LCSC Part #'].strip()):
                badlc.append((r['Comment'], ','.join(refs), r['LCSC Part #'] or '(空)'))
        print(f'BOM: {bom}（{len(brefs)} 个位号）')
        if badlc:
            errs.append(f'BOM 有 {len(badlc)} 行料号不是 C+数字（在符号的 {a.lcsc_field} 字段补上，或确认这些件不贴）')
            for x in badlc[:40]:
                print('   料号异常:', x)
        crefs = {r['Ref'] for r in rows}
        miss = sorted(crefs - brefs)
        if miss:
            errs.append(f'CPL 里有、BOM 里没有的位号 {miss[:30]}')
        extra = sorted(brefs - crefs)
        if extra:
            print(f'   BOM 有、CPL 没有（通孔件/DNP/板上缺件，逐个确认）：{extra[:40]}')
    print('\n' + ('\n'.join('❌ ' + e for e in errs) if errs else '✅ 基本自检通过'))
    print('下一步（缺一不可）：python3 gerber_check.py ' + zp + '   ← 读要上传的那一份本身')
    sys.exit(1 if errs else 0)


if __name__ == '__main__':
    main()
