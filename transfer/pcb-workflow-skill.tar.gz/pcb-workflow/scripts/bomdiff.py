#!/usr/bin/env python3
"""两份 BOM 按位号逐颗对比 + 废料号扫描 —— 规则 0b 换料的验收判据。

    python3 bomdiff.py A B [--lcsc-field LCSC] [--no-stock-check]

A / B 可以是：
  *.csv / *.tsv    kicad-cli sch export bom 导出的、或嘉立创格式 BOM（Comment,Designator,Footprint,LCSC Part #）
  *.xlsx           嘉立创/立创商城导出的 BOM（带 JLCPCB Stock / Price 等列）
  *.kicad_pcb      直接读 PCB 里每个封装实例身上的字段（= “PCB 侧 BOM”）
  *.xml            kicad-cli sch export netlist --format kicadxml 的网表（= “原理图侧 BOM”）

典型用法（换料之后，两侧各出一份，差异必须为 0）：
    kicad-cli sch export netlist --format kicadxml -o sch.xml board.kicad_sch
    python3 bomdiff.py sch.xml board.kicad_pcb
原理图改了、「从原理图更新 PCB」没做（或做的时候没勾字段），这里就会露馅。

判据（任何一条不满足退出码 1）：
  - 两边位号集合相同
  - 每个位号的 料号(LCSC) / 值 / 封装 三项相同
  - 料号必须是 C 开头接纯数字（空、带 .1 后缀、制造商型号都算废号）
  - 表里有库存/单价列时，不许出现 空、'/'、'...'
纯标准库。
"""
import argparse, csv, io, os, re, sys, zipfile
import xml.etree.ElementTree as ET

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

DES = ['designator', 'reference', 'refs', 'ref', '位号']
LCSC = ['lcsc', 'lcsc part #', 'lcsc part', 'lcsc#', 'supplier part', 'jlcpcb part #', 'lcsc part number', '立创编号']
VAL = ['value', 'comment', 'val', '值']
FP = ['footprint', 'package', '封装']
MPN = ['mpn', 'manufacturer part', 'mfr. part #', 'manufacturer part number', '制造商编号']
STOCK = ['jlcpcb stock', 'jlcpcb price', 'lcsc stock', 'lcsc price']


def expand(refs):
    out = []
    for tok in re.split(r'[,\s;]+', refs.strip()):
        if not tok:
            continue
        m = re.fullmatch(r'([A-Za-z#_]+)(\d+)-(?:[A-Za-z#_]+)?(\d+)', tok)  # R1-R4 / R1-4
        if m:
            out += [f'{m.group(1)}{i}' for i in range(int(m.group(2)), int(m.group(3)) + 1)]
        else:
            out.append(tok)
    return out


def pick(h, names):
    hl = [x.strip().lower() for x in h]
    for n in names:
        if n in hl:
            return hl.index(n)
    return None


def from_rows(rows, lcsc_field):
    rows = [r for r in rows if any(c.strip() for c in r)]
    hi = next(i for i, r in enumerate(rows) if pick(r, DES) is not None)
    h = rows[hi]
    lc_names = ([lcsc_field.lower()] if lcsc_field else []) + LCSC
    iD, iL, iV, iF, iM = pick(h, DES), pick(h, lc_names), pick(h, VAL), pick(h, FP), pick(h, MPN)
    iS = [i for i, x in enumerate(h) if x.strip().lower() in STOCK]
    d = {}
    for r in rows[hi + 1:]:
        g = lambda i: (r[i].strip() if i is not None and i < len(r) else '')
        for des in expand(g(iD)):
            d[des] = dict(lcsc=g(iL), val=g(iV), fp=g(iF).split(':')[-1], mpn=g(iM),
                          stock=[g(i) for i in iS])
    return d, iL is not None


def read_csv(p, lcsc_field):
    raw = open(p, encoding='utf-8-sig', errors='replace').read()
    dl = '\t' if p.endswith('.tsv') or raw.count('\t') > raw.count(',') else ','
    return from_rows(list(csv.reader(io.StringIO(raw), delimiter=dl)), lcsc_field)


def read_xlsx(p, lcsc_field):
    ns = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
    z = zipfile.ZipFile(p)
    ss = []
    if 'xl/sharedStrings.xml' in z.namelist():
        for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall(ns + 'si'):
            ss.append(''.join(t.text or '' for t in si.iter(ns + 't')))
    sheet = sorted(n for n in z.namelist() if n.startswith('xl/worksheets/sheet'))[0]
    rows = []
    for row in ET.fromstring(z.read(sheet)).iter(ns + 'row'):
        cells = {}
        for c in row.findall(ns + 'c'):
            col = re.match(r'[A-Z]+', c.get('r', 'A')).group(0)
            idx = 0
            for ch in col:
                idx = idx * 26 + ord(ch) - 64
            v = c.find(ns + 'v')
            is_ = c.find(ns + 'is')
            txt = (ss[int(v.text)] if c.get('t') == 's' else v.text) if v is not None else \
                (''.join(t.text or '' for t in is_.iter(ns + 't')) if is_ is not None else '')
            cells[idx - 1] = txt or ''
        rows.append([cells.get(i, '') for i in range(max(cells) + 1)] if cells else [])
    return from_rows(rows, lcsc_field)


def read_pcb(p, lcsc_field):
    import kisexp as S
    t = S.load(p)
    d = {}
    for fp in S.findall(t, 'footprint'):
        pr = S.props(fp)
        ref = pr.get('Reference', '')
        if not ref or ref.startswith('#'):
            continue
        attr = S.find(fp, 'attr')
        if attr and ('exclude_from_bom' in attr or 'board_only' in attr):
            continue
        lc = pr.get(lcsc_field) if lcsc_field else None
        if lc is None:
            lc = next((v for k, v in pr.items() if k.lower() in LCSC), '')
        d[ref] = dict(lcsc=lc, val=pr.get('Value', ''), fp=str(fp[1]).split(':')[-1], mpn=pr.get('MPN', ''), stock=[])
    return d, True


def read_xml(p, lcsc_field):
    root = ET.parse(p).getroot()
    d = {}
    for c in root.iter('comp'):
        f = {x.get('name'): (x.text or '') for x in c.iter('field')}
        if any(x.get('name') in ('exclude_from_bom', 'dnp') for x in c.iter('property')):
            continue
        lc = f.get(lcsc_field) if lcsc_field else None
        if lc is None:
            lc = next((v for k, v in f.items() if k.lower() in LCSC), '')
        d[c.get('ref')] = dict(lcsc=lc, val=c.findtext('value') or '', fp=(c.findtext('footprint') or '').split(':')[-1],
                               mpn=f.get('MPN', ''), stock=[])
    return d, True


def load(p, lcsc_field):
    ext = p.lower().rsplit('.', 1)[-1]
    return dict(csv=read_csv, tsv=read_csv, txt=read_csv, xlsx=read_xlsx, kicad_pcb=read_pcb, xml=read_xml)[ext](p, lcsc_field)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('a')
    ap.add_argument('b', nargs='?')
    ap.add_argument('--lcsc-field', default='LCSC', help='符号/封装上存立创编号的字段名')
    ap.add_argument('--no-stock-check', action='store_true')
    ap.add_argument('--fields', default='lcsc,val,fp',
                    help='要比的字段：lcsc,val,fp,mpn（和嘉立创 BOM 比时封装名体系不同，去掉 fp）')
    a = ap.parse_args()
    A, ha = load(a.a, a.lcsc_field)
    sets = [(a.a, A, ha)]
    bad_total = 0
    if a.b:
        B, hb = load(a.b, a.lcsc_field)
        sets.append((a.b, B, hb))
        print(f'{a.a} 位号 {len(A)} | {a.b} 位号 {len(B)}')
        oa, ob = sorted(set(A) - set(B)), sorted(set(B) - set(A))
        if oa:
            print('只在前者:', oa)
        if ob:
            print('只在后者:', ob)
        diff = []
        for k in sorted(set(A) & set(B)):
            for f in a.fields.split(','):
                nm = dict(lcsc='料号', val='值', fp='封装', mpn='型号')[f]
                x, y = A[k][f], B[k][f]
                if x != y and (f == 'lcsc' or (x and y)):  # 值/封装：一侧整列缺失时不比
                    diff.append((k, nm, x, y))
        print('差异条数:', len(diff))
        for k, nm, x, y in diff:
            print(f'   {k:8} {nm}: {x!r}  vs  {y!r}')
        bad_total += len(oa) + len(ob) + len(diff)
    for name, M, has_lcsc in sets:
        bad = []
        if not has_lcsc:
            print(f'⚠ {name} 没有料号列（{a.lcsc_field} / LCSC Part # …），跳过废号扫描')
            continue
        for k, v in sorted(M.items()):
            if not re.fullmatch(r'C\d+', v['lcsc'] or ''):
                bad.append((k, v['lcsc'] or '(空)'))
            elif not a.no_stock_check and v['stock'] and any(x in ('/', '...', '') for x in v['stock']):
                bad.append((k, v['lcsc'] + ' 库存/单价列异常 ' + repr(v['stock'])))
        print(f'{name}：废号/缺库存价格 {len(bad)} 行')
        for x in bad[:60]:
            print('   ', x)
        bad_total += len(bad)
    sys.exit(1 if bad_total else 0)


if __name__ == '__main__':
    main()
