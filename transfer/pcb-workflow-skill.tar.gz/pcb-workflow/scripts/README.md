# KiCad 自动化脚本（跨项目复用）

这些脚本是本 skill 各条规则的**执行工具**，全部 Python，2026-09-26 在 KiCad 10.0.6 自带示例工程
（pic_programmer / StickHub / complex_hierarchy / RoyalBlue54L-Feather）上实测过，包括人为制造的故障样例。
旧版的嘉立创EDA CDP 脚本（`cdp.js dump.js conn.js scan.js space.js drc*.js maze.js fpzip.js shot.js page.js silk_scan.js`）已随
「只用 KiCad」的改令全部删除。

## 先决条件

- `kicad-cli`（KiCad 10）在 PATH 中；`kicad-python` = 带 `pcbnew` 的 python3。先真跑一次：
  `kicad-cli version`、`kicad-python -c "import pcbnew"`。不存在就运行项目的安装脚本或按 KiCad 官方方式安装。
- ⚠ chroot 包装的 `kicad-cli`/`kicad-python` **只能访问 `/home/user` 与 `/tmp`**。skill 装在别处时：
  `mkdir -p /tmp/pcbws && cp -r <skill>/scripts/* /tmp/pcbws/`，然后 `kicad-python /tmp/pcbws/pcb_check.py …`。
  纯 python 脚本（下表"python3"那几个）可以原地用系统 python3 跑，但它们调用的 kicad-cli 仍受同样限制（工程要在可访问路径下）。
- 只用标准库；`kisexp.py` 是共享的 S-表达式解析器，与脚本放在同一目录。

## 脚本清单

| 脚本 | 解释器 | 用途 | 对应规则 |
|---|---|---|---|
| `models.py` | python3 | 模型分工：查看/校验（画图≠复核厂商、启动器可用）/切换配置档/改角色，配置在 `models.toml` | 00c、00d |
| `sch_conn.py` | python3 | **原理图连通性三判据**：① ERC（权威）② 网表 XML 并查集（悬空脚、两脚件断一端、整颗悬空、器件自短路、单脚网络）③ `.kicad_sch` 几何并查集（死头配对、**同网多名短路**）+ 名字消失检查；`--show` 并排打印同构电路网络 | 00 ⓪⓪b①a、A1 |
| `bomdiff.py` | python3 | 两份 BOM 逐位号比 料号/值/封装 + 废号扫描；输入可为 csv / xlsx / `.kicad_pcb`（PCB 侧字段）/ 网表 xml（原理图侧） | 0b |
| `fp_compare.py` | python3 | 封装逐焊盘核对（实测间距、所有的孔、courtyard、极性丝印、3D）/ 两个封装逐焊盘比对；输入 `.kicad_mod` 或 `board.kicad_pcb:位号` | 0b、0d、取库 |
| `jlc_fab.py` | python3 | kicad-cli 出嘉立创 Gerber zip + BOM（`LCSC Part #`）+ CPL，并自检料号/位号/旋转 | 2b ② |
| `gerber_check.py` | python3 | 钻孔表、过孔盘径（X2 ViaPad）、丝印越界（包围盒 + 真实板框多边形）、泪滴小区域计数、板尺寸；`--cam` 读板厂 CAM 钻孔数孔 | 2b ①⑦⑧⑨、2c |
| `drc_report.py` | python3 | 跑 `kicad-cli pcb drc --refill-zones --schematic-parity`，**点名被 ignore 的检查**，按对象计数找根因 | 2、0b |
| `pcb_check.py` | kicad-python | courtyard 干涉、文字↔文字/焊盘（墨迹多边形）、越界、位号间隙/角度、字号下限、焊盘到板边、via-in-pad、**电感下方禁铜**、孔清单与工艺下限、泪滴数、旋转全 0 | 1.3、3、0d、0b、2c、2d |
| `pcb_conn.py` | kicad-python | **自写铜并查集**（焊盘/走线/过孔/覆铜岛）vs KiCad ratsnest 对账；悬空走线端点 | 2 |
| `dsn_io.py` | kicad-python | Freerouting 的 DSN 导出（可去走线/去覆铜）/ SES 导入另存 | 2 |
| `hivedash.py` | python3 | 多代理进度仪表盘（判据 = 文件是否存在） | — |
| `kisexp.py` | （库） | S-表达式解析器 | — |

## 典型串法

**原理图定稿（闸口 A，规则 00）**
```bash
python3 sch_conn.py proj.kicad_sch --show 'SW|SW7' --json sch_conn.json   # P0=P1=0 才往下走（退出码 2/1/0）
kicad-cli sch export pdf -o sch.pdf proj.kicad_sch                         # 目视（规则 00 ③）
```

**验收一块板（闸口 B5）**
```bash
python3 drc_report.py board.kicad_pcb            # 违规/未连接/parity = 0，且被 ignore 的检查逐项确认
kicad-python pcb_conn.py board.kicad_pcb         # 自写并查集与 ratsnest 一致且为 0
kicad-python pcb_check.py board.kicad_pcb        # 三项干涉 0/0/0 + 越界 0；⑦⑧⑨⑩ 逐条看
```

**换料（规则 0b）**
```bash
python3 fp_compare.py 旧.kicad_mod 新.kicad_mod        # 或 board.kicad_pcb:C4 新.kicad_mod
# 原理图改字段 → F8 从原理图更新 PCB（勾「用符号指定的封装替换」「从符号更新封装字段」）
kicad-cli sch export netlist --format kicadxml -o sch.xml proj.kicad_sch
python3 bomdiff.py sch.xml board.kicad_pcb              # 差异 0
python3 drc_report.py board.kicad_pcb                   # parity 0
```

**下单（规则 2b）**
```bash
python3 jlc_fab.py board.kicad_pcb --out fab/
python3 gerber_check.py fab/board-GERBER.zip            # 读要上传的那一份本身
python3 gerber_check.py --cam <CAM 回读>/ok/drl --boards 20
```

**Freerouting（可选）**
```bash
kicad-python dsn_io.py export board.kicad_pcb b.dsn --strip-zones
freerouting -de b.dsn -do b.ses -mp 20
kicad-python dsn_io.py import board.kicad_pcb b.ses routed.kicad_pcb
```

## 2026-09-26 实测记录（KiCad 10.0.6）

| 脚本 | 样例 | 结果 |
|---|---|---|
| `sch_conn.py` | pic_programmer / StickHub / complex_hierarchy 原样 | P0=P1=0（ERC 只有库表类 info） |
| `sch_conn.py` | pic_programmer 人为把 R2 右移 1.27mm + 在 VPP_ON 标签点再放一个 FAKE_SHORT 标签 | 退出码 2：ERC `pin_not_connected`×3、`multiple_net_names`×1；网表「整颗器件全脚悬空」1；几何「同网多名 ['FAKE_SHORT','VPP_ON']」、死头配对 `R2.1 ← (71.12,46.99) 距 1.27mm`；「VPP_ON 不在网表里」 |
| `pcb_check.py` | StickHub | courtyard 干涉 59（去掉 7 个无 courtyard 件后 45，与把 `courtyards_overlap` 打开后的 KiCad DRC 45 条一致）；文字↔文字按墨迹 0（按 bbox 会虚报 38）；泪滴 0 |
| `pcb_check.py` | RoyalBlue54L（8 层） | 泪滴 263；孔径 <0.3 的 208 个（含 183 颗 0.00001mm 的"过孔"）；电感 L1 下方 8 层都有铜、无禁止区 |
| `pcb_conn.py` | 三块示例板 | 与 ratsnest 一致（0/0）；StickHub 人为各删一段 3 个网络 → 自写 1 条 = KiCad 1 条（另两网有冗余铜） |
| `gerber_check.py` | RoyalBlue54L / StickHub | 钻孔表、ViaPad 盘径 [0.35,0.4,0.45] 报错；泪滴小区域 167+58 vs 0+0；板外放一个 BOOT → 丝印越界 52 点聚成两簇 |
| `bomdiff.py` | RoyalBlue54L 网表 vs `.kicad_pcb` | 抓出 J6：原理图侧 LCSC 空、PCB 侧 C5213747 |
| `jlc_fab.py` | RoyalBlue54L | 18 个文件的 zip、CPL 45 件、BOM 48 位号；报 J6 料号为空 |
| `fp_compare.py` | JST XH 3P vs PinHeader 1x03 | 实测间距 2.5 vs 2.54，差异 8 条；USB-C GCT 列出 NPTH×2 + 两种槽孔、`SH` 带孔 |
| `drc_report.py` | StickHub | DRC 0 但点名 8 项 ignore（含 courtyards_overlap/silk_overlap/silk_over_copper） |
| `dsn_io.py` | pic_programmer 去走线去覆铜 | DSN → Freerouting 2.4.1 9.5s → SES 导回 361 段，未连接 0 |

## 三条使用铁律

1. **不要相信脚本的返回值，也不要相信 KiCad 单一判据的返回值** —— 每一步出 PDF/SVG 目视，
   或用另一个独立判据交叉验证（上表每一行都是这么验的）。
2. **动手前先存基线**：改板前拷一份 `.kicad_pcb`/`.kicad_sch`（或 git 提交），改完 diff。
3. **删图元前把完整属性存下来**（不只是 uuid），否则想恢复都没有依据；pcbnew `Delete()` 之后对象已释放，先取属性再删。
