#!/usr/bin/env python3
"""PCB 干涉 / 丝印 / 板边 / 过孔进焊盘 / 电感禁铜 / 孔清单 —— 规则 1.3、3.x、0d、0b、2c、2d，闸口 B1/B4/B5。

必须用带 pcbnew 的 python 跑：
    kicad-python pcb_check.py board.kicad_pcb [--json out.json] [选项]
⚠ chroot 版 kicad-python 只能访问 /home/user 与 /tmp：脚本和板子都要放在这两处之下
  （skill 装在 /root 下时，先 `cp -r <skill>/scripts /tmp/pcbws/` 再跑）。

检查项（全部基于 KiCad 真实几何，不是 bbox 猜测，除非特别注明）：
  ① 器件↔器件      同面 courtyard 多边形求交面积 > 0 即干涉（无 courtyard 的件用不含文字的 bbox 兜底并点名）
  ② 文字↔文字      丝印层上所有可见文字（位号 + 独立文字 + 其它可见字段）两两墨迹多边形
                   （外扩 --silk-clear）求交；不用 bbox —— 45° 文字的 bbox 会虚报
  ③ 文字↔焊盘      文字墨迹(+净空) ↔ 同面焊盘多边形（自己的焊盘和别人的都算）
  ④ 文字越界       文字墨迹每个顶点都必须在板框多边形内（非凸/缺口正确处理）
  ⑤ 位号到本体间隙 目标 ≤0.5mm(≈20mil)，>2.54mm(100mil) 必须报告；角度只允许 0°/90°
  ⑥ 多余丝印       丝印层上可见的 Value/其它字段、字高 <0.8mm 或线宽 <0.15mm（嘉立创下限）
  ⑦ 焊盘到板边     < --edge（默认 0.3mm）报告（规则 0d ③：“焊盘在板内”≠“离板边够远”）
  ⑧ 过孔进焊盘     过孔中心落在焊盘内（同网 DRC 不报，但未塞孔会吸锡，DFM 会挑）
  ⑨ 电感下方禁铜   匹配 --inductor 的器件，courtyard 外扩 --ind-margin 后扣掉自身焊盘，
                   逐铜层统计覆铜面积 / 穿过的走线 / 过孔；并检查是否有覆盖全部铜层的禁止区
  ⑩ 孔清单与工艺   过孔/PTH/NPTH/槽孔按孔径汇总；最小孔 < 0.3mm、过孔外径 < 0.45mm 报告（嘉立创四层下限）
  ⑪ 泪滴           泪滴区域数量（=0 视为没加，规则 2c）
  ⑫ 旋转           全部封装角度都是 0 → CPL 角度不可信，报告
"""
import argparse, collections, json, math, re, statistics, sys

import pcbnew

MM = 1e6
IU = pcbnew.FromMM(1)  # 1mm 对应的内部单位


def mm(v):
    return v / IU


def bbox_t(b):
    return (b.GetLeft(), b.GetTop(), b.GetRight(), b.GetBottom())


def ov(a, b):
    w = min(a[2], b[2]) - max(a[0], b[0])
    h = min(a[3], b[3]) - max(a[1], b[1])
    return (w, h) if (w > 0 and h > 0) else None


def gap(a, b):
    dx = max(a[0] - b[2], b[0] - a[2], 0)
    dy = max(a[1] - b[3], b[1] - a[3], 0)
    return math.hypot(dx, dy)


def grow(r, d):
    return (r[0] - d, r[1] - d, r[2] + d, r[3] + d)


def rect_poly(r):
    p = pcbnew.SHAPE_POLY_SET()
    p.NewOutline()
    for x, y in ((r[0], r[1]), (r[2], r[1]), (r[2], r[3]), (r[0], r[3])):
        p.Append(int(x), int(y))
    return p


def inter_area(a, b):
    c = pcbnew.SHAPE_POLY_SET(a)
    c.BooleanIntersection(b)
    return c.Area()


def side_of_layer(layer):
    name = pcbnew.LayerName(layer) if hasattr(pcbnew, 'LayerName') else ''
    if layer in (pcbnew.F_SilkS, pcbnew.F_Cu, pcbnew.F_CrtYd, pcbnew.F_Fab):
        return 'F'
    if layer in (pcbnew.B_SilkS, pcbnew.B_Cu, pcbnew.B_CrtYd, pcbnew.B_Fab):
        return 'B'
    return name


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('pcb')
    ap.add_argument('--json')
    ap.add_argument('--edge', type=float, default=0.3, help='焊盘到板边最小距离 mm')
    ap.add_argument('--inductor', default=r'^(L|T|FB)\d', help='电感类位号正则（规则 2d）')
    ap.add_argument('--ind-margin', type=float, default=0.25, help='电感禁铜区在 courtyard 外再扩 mm')
    ap.add_argument('--min-drill', type=float, default=0.3)
    ap.add_argument('--min-via-pad', type=float, default=0.45)
    ap.add_argument('--silk-clear', type=float, default=0.1, help='文字墨迹外扩净空 mm（≈4mil）')
    ap.add_argument('--gap-warn', type=float, default=2.54, help='位号离本体超过此值(mm)报告')
    a = ap.parse_args()

    b = pcbnew.LoadBoard(a.pcb)
    fps = list(b.GetFootprints())
    R = collections.OrderedDict()
    maxerr = pcbnew.FromMM(0.005)

    # ---------- 板框
    outline = pcbnew.SHAPE_POLY_SET()
    has_outline = b.GetBoardPolygonOutlines(outline, True)
    inside = lambda x, y: outline.Contains(pcbnew.VECTOR2I(int(x), int(y)))

    # ---------- 器件本体（courtyard）
    bodies = []
    for fp in fps:
        side = 'B' if fp.IsFlipped() else 'F'
        cy = fp.GetCourtyard(pcbnew.B_CrtYd if fp.IsFlipped() else pcbnew.F_CrtYd)
        if cy.OutlineCount() == 0:
            bb = fp.GetBoundingBox(False)  # 不含文字
            poly, src = rect_poly(bbox_t(bb)), 'bbox(无courtyard)'
        else:
            poly, src = pcbnew.SHAPE_POLY_SET(cy), 'courtyard'
        pb = poly.BBox()
        bodies.append(dict(ref=fp.GetReference(), fp=fp, side=side, poly=poly, src=src,
                           bb=(pb.GetLeft(), pb.GetTop(), pb.GetRight(), pb.GetBottom())))
    no_cy = [x['ref'] for x in bodies if x['src'] != 'courtyard']

    r1 = []
    for i in range(len(bodies)):
        for j in range(i + 1, len(bodies)):
            A, B = bodies[i], bodies[j]
            if A['side'] != B['side'] or not ov(A['bb'], B['bb']):
                continue
            ar = inter_area(A['poly'], B['poly'])
            if ar > 0:
                r1.append((A['ref'], B['ref'], round(ar / IU / IU, 3)))
    R['① 器件↔器件 courtyard 干涉'] = r1

    # ---------- 文字（丝印层上可见的）
    silk = {pcbnew.F_SilkS: 'F', pcbnew.B_SilkS: 'B'}
    texts = []
    for fp in fps:
        for fld in fp.GetFields():
            if fld.IsVisible() and fld.GetLayer() in silk and fld.GetText().strip():
                texts.append(dict(kind='ref' if fld.GetName() == 'Reference' else 'field:' + fld.GetName(),
                                  owner=fp.GetReference(), txt=fld.GetShownText(False), obj=fld,
                                  side=silk[fld.GetLayer()], bb=bbox_t(fld.GetBoundingBox())))
        for it in fp.GraphicalItems():
            if isinstance(it, pcbnew.PCB_TEXT) and it.IsVisible() and it.GetLayer() in silk:
                texts.append(dict(kind='fptext', owner=fp.GetReference(), txt=it.GetShownText(False), obj=it,
                                  side=silk[it.GetLayer()], bb=bbox_t(it.GetBoundingBox())))
    for d in b.GetDrawings():
        if isinstance(d, pcbnew.PCB_TEXT) and d.GetLayer() in silk:
            texts.append(dict(kind='free', owner='', txt=d.GetShownText(False), obj=d,
                              side=silk[d.GetLayer()], bb=bbox_t(d.GetBoundingBox())))

    clr = pcbnew.FromMM(a.silk_clear)
    for t in texts:  # 墨迹多边形（外扩净空）——“bbox 重叠 ≠ 墨迹重叠”，用真实笔画判
        ink = pcbnew.SHAPE_POLY_SET()
        t['obj'].TransformShapeToPolygon(ink, t['obj'].GetLayer(), 0, maxerr, pcbnew.ERROR_INSIDE)
        t['ink'] = ink
        big = pcbnew.SHAPE_POLY_SET(ink)
        if clr:
            big.Inflate(clr, pcbnew.CORNER_STRATEGY_ROUND_ALL_CORNERS, maxerr)
        t['inkc'] = big
        if ink.OutlineCount():
            ib = ink.BBox()
            t['bb'] = (ib.GetLeft(), ib.GetTop(), ib.GetRight(), ib.GetBottom())

    r2 = []
    for i in range(len(texts)):
        for j in range(i + 1, len(texts)):
            A, B = texts[i], texts[j]
            if A['side'] == B['side'] and ov(grow(A['bb'], clr), B['bb']) and inter_area(A['inkc'], B['ink']) > 0:
                r2.append((A['txt'], B['txt']))
    R['② 文字↔文字 重叠'] = r2

    # ---------- 焊盘多边形
    pads = []
    for fp in fps:
        for p in fp.Pads():
            sides = set()
            if p.IsOnLayer(pcbnew.F_Cu):
                sides.add('F')
            if p.IsOnLayer(pcbnew.B_Cu):
                sides.add('B')
            poly = pcbnew.SHAPE_POLY_SET()
            lay = pcbnew.F_Cu if 'F' in sides else pcbnew.B_Cu
            if sides:
                p.TransformShapeToPolygon(poly, lay, 0, maxerr, pcbnew.ERROR_INSIDE)
            elif p.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH:
                sides = {'F', 'B'}
                p.TransformHoleToPolygon(poly, 0, maxerr, pcbnew.ERROR_INSIDE)
            pb = poly.BBox() if poly.OutlineCount() else p.GetBoundingBox()
            pads.append(dict(owner=fp.GetReference(), num=p.GetNumber(), net=p.GetNetname(), pad=p,
                             sides=sides, poly=poly, bb=(pb.GetLeft(), pb.GetTop(), pb.GetRight(), pb.GetBottom())))

    r3 = []
    for t in texts:
        for p in pads:
            if t['side'] not in p['sides'] or not ov(grow(t['bb'], clr), p['bb']):
                continue
            if p['poly'].OutlineCount() == 0 or inter_area(t['inkc'], p['poly']) > 0:
                r3.append((t['txt'], f"{p['owner']}.{p['num']}", p['net']))
    R['③ 文字↔焊盘 重叠'] = r3

    r4 = []
    if has_outline and outline.OutlineCount():
        for t in texts:
            ink = t['ink']
            pts = [(ink.Outline(k).CPoint(v).x, ink.Outline(k).CPoint(v).y)
                   for k in range(ink.OutlineCount()) for v in range(ink.Outline(k).PointCount())]
            n_out = sum(1 for x, y in pts if not inside(x, y))
            if n_out:
                r4.append((t['txt'], t['kind'], f'{n_out}/{len(pts)} 个墨迹顶点在板外', [round(mm(v), 2) for v in t['bb']]))
        for bd in bodies:
            x0, y0, x1, y1 = bd['bb']
            if not all(inside(x, y) for x, y in ((x0, y0), (x1, y0), (x0, y1), (x1, y1))):
                r4.append((bd['ref'], '器件本体', '部分在板外（连接器伸出板边时需确认是有意的）', []))
    R['④ 文字/器件越界'] = r4

    # ---------- ⑤ 位号间隙与角度
    body_of = {x['ref']: x for x in bodies}
    gaps, far, bad_angle = [], [], []
    for t in texts:
        if t['kind'] != 'ref':
            continue
        bd = body_of.get(t['owner'])
        if bd:
            g = mm(gap(t['bb'], bd['bb']))
            gaps.append(g)
            if g > a.gap_warn:
                far.append((t['owner'], round(g, 2)))
        ang = t['obj'].GetDrawRotation().AsDegrees() if hasattr(t['obj'], 'GetDrawRotation') else t['obj'].GetTextAngleDegrees()
        ang = ((round(ang, 3) % 360) + 360) % 360  # 先归一：-90/270/360 都要折算
        if ang not in (0.0, 90.0):
            bad_angle.append((t['owner'], ang))
    R['⑤a 位号离本体过远(>%.2fmm)' % a.gap_warn] = far
    R['⑤b 位号角度不是 0/90'] = bad_angle
    angle_stat = collections.Counter(
        ((round(t['obj'].GetDrawRotation().AsDegrees(), 1) % 360) + 360) % 360 for t in texts if t['kind'] == 'ref')

    # ---------- ⑥ 多余丝印 / 字号
    extra = [(t['owner'], t['kind'], t['txt']) for t in texts if t['kind'].startswith('field:')]
    small = []
    for t in texts:
        h, w = mm(t['obj'].GetTextHeight()), mm(t['obj'].GetEffectiveTextPenWidth())
        if h < 0.8 - 1e-6 or w < 0.15 - 1e-6:
            small.append((t['txt'], round(h, 3), round(w, 3)))
    R['⑥a 丝印上可见的非位号字段'] = extra
    R['⑥b 字高<0.8mm 或线宽<0.15mm'] = small

    # ---------- ⑦ 焊盘到板边
    edge_hits = []
    if has_outline and outline.OutlineCount():
        lim = mm(pcbnew.FromMM(a.edge))
        segs = []  # 板框所有边（含内孔/缺口），单位 mm
        chains = []
        for k in range(outline.OutlineCount()):
            chains.append(outline.Outline(k))
            for h in range(outline.HoleCount(k)):
                chains.append(outline.Hole(k, h))
        for ch in chains:
            n = ch.PointCount()
            for v in range(n):
                p0, p1 = ch.CPoint(v), ch.CPoint((v + 1) % n)
                segs.append((mm(p0.x), mm(p0.y), mm(p1.x), mm(p1.y)))

        def dseg(px, py, s):
            x1, y1, x2, y2 = s
            dx, dy = x2 - x1, y2 - y1
            L = dx * dx + dy * dy
            t = 0 if L == 0 else max(0, min(1, ((px - x1) * dx + (py - y1) * dy) / L))
            return math.hypot(x1 + t * dx - px, y1 + t * dy - py)
        for p in pads:
            if p['poly'].OutlineCount() == 0:
                continue
            x0, y0, x1, y1 = (mm(v) for v in p['bb'])
            near = [s for s in segs if min(s[0], s[2]) - lim <= x1 and max(s[0], s[2]) + lim >= x0
                    and min(s[1], s[3]) - lim <= y1 and max(s[1], s[3]) + lim >= y0]
            if not near:
                continue
            dmin = None
            for k in range(p['poly'].OutlineCount()):
                ch = p['poly'].Outline(k)
                for v in range(ch.PointCount()):
                    pt = ch.CPoint(v)
                    d = min(dseg(mm(pt.x), mm(pt.y), s) for s in near)
                    dmin = d if dmin is None else min(dmin, d)
            if dmin is not None and dmin < lim:
                edge_hits.append((f"{p['owner']}.{p['num']}", round(dmin, 3)))
    R['⑦ 焊盘到板边 < %.2fmm' % a.edge] = edge_hits

    # ---------- ⑧ 过孔进焊盘 + ⑩ 孔清单
    vias = [t for t in b.Tracks() if isinstance(t, pcbnew.PCB_VIA)]
    vip = []
    for v in vias:
        pos = v.GetPosition()
        for p in pads:
            if p['pad'].GetAttribute() == pcbnew.PAD_ATTRIB_NPTH:
                continue
            x0, y0, x1, y1 = p['bb']
            if x0 <= pos.x <= x1 and y0 <= pos.y <= y1 and p['pad'].HitTest(pos, 0):
                vip.append((f"{p['owner']}.{p['num']}", p['net'], v.GetNetname(),
                            round(mm(v.GetDrillValue()), 4), '同网' if p['net'] == v.GetNetname() else '⚠异网'))
    R['⑧ 过孔中心落在焊盘内 (via-in-pad)'] = vip

    holes = collections.Counter()
    small_holes, small_vias = [], []
    for v in vias:
        d, w = mm(v.GetDrillValue()), mm(v.GetWidth(pcbnew.F_Cu) if hasattr(v, 'GetWidth') else v.GetWidth())
        holes[('VIA', float(f'{d:.4g}'))] += 1
        if d < a.min_drill - 1e-6:
            small_holes.append(('via', round(d, 4), f'@({mm(v.GetPosition().x):.2f},{mm(v.GetPosition().y):.2f})'))
        if w < a.min_via_pad - 1e-6:
            small_vias.append((round(d, 4), round(w, 3), f'@({mm(v.GetPosition().x):.2f},{mm(v.GetPosition().y):.2f})'))
    for p in pads:
        pd = p['pad']
        if pd.GetAttribute() not in (pcbnew.PAD_ATTRIB_PTH, pcbnew.PAD_ATTRIB_NPTH):
            continue
        ds = pd.GetDrillSize()
        kind = 'NPTH' if pd.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH else 'PTH'
        if ds.x != ds.y:
            kind += '槽'
            key = (kind, f'{mm(min(ds.x, ds.y)):.3f}x{mm(max(ds.x, ds.y)):.3f}')
        else:
            key = (kind, round(mm(ds.x), 3))
        holes[key] += 1
        if kind.startswith('PTH') and mm(min(ds.x, ds.y)) < a.min_drill - 1e-6:
            small_holes.append((f"{p['owner']}.{p['num']}", round(mm(min(ds.x, ds.y)), 3), kind))
    edge_in_fp = [(fp.GetReference(), sum(1 for g in fp.GraphicalItems() if g.GetLayer() == pcbnew.Edge_Cuts))
                  for fp in fps if any(g.GetLayer() == pcbnew.Edge_Cuts for g in fp.GraphicalItems())]
    R['⑩a 孔径 < %.2fmm' % a.min_drill] = small_holes
    R['⑩b 过孔外径 < %.2fmm' % a.min_via_pad] = small_vias

    # ---------- ⑨ 电感下方禁铜
    rx = re.compile(a.inductor)
    cu_layers = [l for l in b.GetEnabledLayers().CuStack()]
    zones = list(b.Zones())
    keepouts = [z for z in zones if z.GetIsRuleArea()]
    ind = []
    for bd in bodies:
        if not rx.search(bd['ref']):
            continue
        area = pcbnew.SHAPE_POLY_SET(bd['poly'])
        area.Inflate(pcbnew.FromMM(a.ind_margin), pcbnew.CORNER_STRATEGY_ROUND_ALL_CORNERS, maxerr) \
            if hasattr(pcbnew, 'CORNER_STRATEGY_ROUND_ALL_CORNERS') else area.Inflate(pcbnew.FromMM(a.ind_margin), 16)
        own = pcbnew.SHAPE_POLY_SET()
        for p in bd['fp'].Pads():
            for l in cu_layers:
                if p.IsOnLayer(l):
                    p.TransformShapeToPolygon(own, l, pcbnew.FromMM(0.2), maxerr, pcbnew.ERROR_OUTSIDE)
        free = pcbnew.SHAPE_POLY_SET(area)
        free.BooleanSubtract(own)
        rep = {}
        for l in cu_layers:
            cu = 0.0
            for z in zones:
                if z.GetIsRuleArea() or not z.IsOnLayer(l) or not z.HasFilledPolysForLayer(l):
                    continue
                f = z.GetFilledPolysList(l)
                if f.OutlineCount():
                    cu += inter_area(f, free)
            ntr = 0
            for t in b.Tracks():
                if isinstance(t, pcbnew.PCB_VIA):
                    if free.Contains(t.GetPosition()):
                        ntr += 1
                    continue
                if t.GetLayer() != l:
                    continue
                s, e = t.GetStart(), t.GetEnd()
                for k in range(1, 10):
                    x = s.x + (e.x - s.x) * k / 10
                    y = s.y + (e.y - s.y) * k / 10
                    if free.Contains(pcbnew.VECTOR2I(int(x), int(y))):
                        ntr += 1
                        break
            if cu > 0 or ntr:
                rep[b.GetLayerName(l)] = dict(铜面积mm2=round(cu / IU / IU, 3), 走线过孔=ntr)
        ko = [z for z in keepouts if z.GetDoNotAllowZoneFills() and inter_area(z.Outline(), area) >= 0.95 * area.Area()]
        ko_all = any(all(z.IsOnLayer(l) for l in cu_layers) for z in ko)
        ind.append(dict(位号=bd['ref'], 区域=f"{mm(bd['bb'][2]-bd['bb'][0]):.2f}x{mm(bd['bb'][3]-bd['bb'][1]):.2f}mm",
                        禁止区覆盖全部铜层=ko_all, 区内有铜=rep))
    R['⑨ 电感下方禁铜'] = [x for x in ind if x['区内有铜'] or not x['禁止区覆盖全部铜层']]

    # ---------- ⑪ 泪滴 ⑫ 旋转
    tds = [z for z in zones if hasattr(z, 'IsTeardropArea') and z.IsTeardropArea()]
    rots = collections.Counter(round(fp.GetOrientationDegrees(), 1) for fp in fps)
    all_zero = len(fps) > 5 and set(rots) == {0.0}

    # ---------- 输出
    print(f'板子 {a.pcb}：{len(fps)} 封装 / {len(pads)} 焊盘 / {len(vias)} 过孔 / 铜层 {b.GetCopperLayerCount()} / '
          f'板框 {"有" if has_outline else "⚠无法闭合"}')
    if no_cy:
        print(f'   ⚠ 无 courtyard 的封装 {len(no_cy)} 个（按不含文字的 bbox 兜底，可能低估本体）：{" ".join(no_cy[:30])}')
    must_zero = ['① 器件↔器件 courtyard 干涉', '② 文字↔文字 重叠', '③ 文字↔焊盘 重叠', '④ 文字/器件越界']
    for k, v in R.items():
        flag = '❌' if (v and k in must_zero) else ('⚠' if v else '✅')
        print(f'\n{flag} {k}：{len(v)}')
        for x in v[:25]:
            print('     ', x)
        if len(v) > 25:
            print(f'      …还有 {len(v) - 25} 条')
    if gaps:
        print(f'\n   位号间隙 mm：中位 {statistics.median(gaps):.2f} / 最大 {max(gaps):.2f}；'
              f'≤0.5mm 的 {sum(g <= 0.5 for g in gaps)}/{len(gaps)}；角度分布 {dict(angle_stat)}')
    print(f'\n   孔清单：' + ', '.join(f'{k[0]} {k[1]}×{n}' for k, n in sorted(holes.items(), key=lambda kv: (kv[0][0], str(kv[0][1])))))
    if edge_in_fp:
        print(f'   ⚠ 封装内含 Edge.Cuts 图形（挖槽/定位柱被画成板框）：{edge_in_fp} —— 核对板厂是否按铣槽处理')
    print(f'   泪滴区域 {len(tds)} 个' + ('  ❌ 没加泪滴（规则 2c）' if not tds else ''))
    print(f'   封装角度分布 {dict(rots)}' + ('  ❌ 全部为 0：CPL 角度不可信（规则 2 第 0 条）' if all_zero else ''))
    print('\n三项验收（规则 1.3）：器件↔器件 %d / 文字↔文字 %d / 文字↔焊盘 %d；越界 %d'
          % (len(r1), len(r2), len(r3), len(r4)))
    if a.json:
        out = {k: v for k, v in R.items()}
        out.update(holes={f'{k[0]} {k[1]}': n for k, n in holes.items()}, teardrops=len(tds),
                   rotations={str(k): n for k, n in rots.items()}, no_courtyard=no_cy)
        json.dump(out, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1, default=str)
    sys.exit(1 if any(R[k] for k in must_zero) else 0)


if __name__ == '__main__':
    main()
