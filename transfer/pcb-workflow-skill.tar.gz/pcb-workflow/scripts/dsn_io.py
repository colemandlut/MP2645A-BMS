#!/usr/bin/env python3
"""Freerouting 往返的 pcbnew 两端（可选工具，规则 2 第 2 步）。

    kicad-python dsn_io.py export board.kicad_pcb out.dsn [--strip-tracks] [--strip-zones]
    freerouting -de out.dsn -do out.ses -mp 20            # 在 chroot 外跑（需要 Java）
    kicad-python dsn_io.py import board.kicad_pcb out.ses routed.kicad_pcb
    kicad-cli pcb drc --refill-zones --format json -o drc.json routed.kicad_pcb

要点（都实测踩过）：
  - DSN 的设计规则来自**同目录同名 .kicad_pro**：拷板必拷 .kicad_pro，否则退回默认 0.2/0.2 规则。
  - 板上有 zone 时 DSN 把该网当 plane，Freerouting 不布它；要让地网走线化就 --strip-zones，
    导回后在 GUI 里重新画/恢复 zone 再填充（pcbnew 进程内新建 ZONE 后 Fill/Save 容易段错误）。
  - 同名封装在 DSN 里共享 image：逐实例几何不同的“同名封装”会让 Freerouting 用第一个实例的焊盘布所有件。
  - 不要拿 Freerouting 反复“优化”已布通的板：KiCad 的 T 接在 DSN 里会被当成未连，导回后多出幻影线。
  - 删除走线：`for t in list(b.Tracks()): b.Delete(t)`；Delete 之后该对象已释放，不要再调它的任何方法。
  - 结果一律再跑 DRC + pcb_conn.py，两个判据都为 0 才算布通；Freerouting 的“完成”不作数。
"""
import sys

import pcbnew


def main():
    if len(sys.argv) < 4 or sys.argv[1] not in ('export', 'import'):
        print(__doc__)
        sys.exit(2)
    cmd, pcb = sys.argv[1], sys.argv[2]
    b = pcbnew.LoadBoard(pcb)
    if cmd == 'export':
        out = sys.argv[3]
        if '--strip-tracks' in sys.argv:
            n = 0
            for t in list(b.Tracks()):
                b.Delete(t)
                n += 1
            print(f'删除走线/过孔 {n}')
        if '--strip-zones' in sys.argv:
            n = 0
            for z in list(b.Zones()):
                if not z.GetIsRuleArea():
                    b.Remove(z)
                    n += 1
            print(f'移除覆铜 {n}（导回后要恢复）')
        ok = pcbnew.ExportSpecctraDSN(b, out)
        print(f'ExportSpecctraDSN -> {out}: {ok}')
        sys.exit(0 if ok else 1)
    ses, out = sys.argv[3], sys.argv[4]
    ok = pcbnew.ImportSpecctraSES(b, ses)
    print(f'ImportSpecctraSES <- {ses}: {ok}')
    if not ok:
        sys.exit(1)
    pcbnew.SaveBoard(out, b)
    tr = list(b.Tracks())
    print(f'已保存 {out}：走线 {sum(1 for t in tr if not isinstance(t, pcbnew.PCB_VIA))}，过孔 {sum(1 for t in tr if isinstance(t, pcbnew.PCB_VIA))}')
    print('下一步：kicad-cli pcb drc --refill-zones ... + kicad-python pcb_conn.py ...（两个判据都为 0 才算布通）')


if __name__ == '__main__':
    main()
