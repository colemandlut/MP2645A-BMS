#!/usr/bin/env python3
"""PCB 铜连通性独立复核（自写并查集）—— 规则 2 “双判据交叉验证”、闸口 B5。

    kicad-python pcb_conn.py board.kicad_pcb [--json out.json] [--nets 'GND|5V']

⚠ chroot 版 kicad-python 只能访问 /home/user 与 /tmp（脚本和板子都要放在其下）。

为什么要有它：KiCad 的 ratsnest / DRC unconnected_items 是主判据，但铁律是
“不信单一返回值，能独立算出来的量，算出来的才是定论”。本脚本只用几何：
  节点 = 焊盘（逐铜层多边形）、走线段/圆弧、过孔、每一块覆铜填充岛（逐层逐岛）
  连接 = 同网 且 同层 且 几何接触：
         走线端点落在焊盘/过孔/另一条走线（含 T 接）/覆铜岛上；过孔圆与焊盘/覆铜岛相交；
         焊盘与覆铜岛面积相交 > 0（花焊盘辐条也算）；同网焊盘互相重叠
  → 每个网络的焊盘被分成几组；组数 > 1 = 没布通。
然后与 KiCad 自己的 ratsnest 未连接数对账：两边不一致就是有一边错了，必须查清再往下走。

附带输出：悬空走线端点（端点什么都没接 —— 删线要“纯修剪”，反复删到收敛再补线）。
⚠ 覆铜要先填充（kicad-cli pcb drc --refill-zones --save-board 或 GUI 按 B），否则岛是旧的。
"""
import argparse, collections, json, math, re, sys

import pcbnew

IU = pcbnew.FromMM(1)
CELL = pcbnew.FromMM(2)


def mm(v):
    return v / IU


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('pcb')
    ap.add_argument('--json')
    ap.add_argument('--nets', help='只看匹配此正则的网络')
    a = ap.parse_args()
    b = pcbnew.LoadBoard(a.pcb)
    b.BuildConnectivity()
    maxerr = pcbnew.FromMM(0.005)
    cu = list(b.GetEnabledLayers().CuStack())
    rx = re.compile(a.nets) if a.nets else None

    nodes = []  # dict(kind, net, layer, bb, ...)

    def add(**k):
        k['i'] = len(nodes)
        nodes.append(k)
        return k

    for fp in b.GetFootprints():
        for p in fp.Pads():
            if p.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH:
                continue
            for l in cu:
                if not p.IsOnLayer(l):
                    continue
                poly = pcbnew.SHAPE_POLY_SET()
                p.TransformShapeToPolygon(poly, l, 0, maxerr, pcbnew.ERROR_INSIDE)
                if not poly.OutlineCount():
                    continue
                bb = poly.BBox()
                add(kind='pad', net=p.GetNetname(), layer=l, poly=poly, name=f'{fp.GetReference()}.{p.GetNumber()}',
                    pad=p, bb=(bb.GetLeft(), bb.GetTop(), bb.GetRight(), bb.GetBottom()))
    tracks = []
    for t in b.Tracks():
        if isinstance(t, pcbnew.PCB_VIA):
            c, r = t.GetPosition(), t.GetWidth(pcbnew.F_Cu) // 2
            for l in cu:
                if t.IsOnLayer(l):
                    add(kind='via', net=t.GetNetname(), layer=l, c=c, r=r, via=t,
                        bb=(c.x - r, c.y - r, c.x + r, c.y + r))
            continue
        w = t.GetWidth()
        if isinstance(t, pcbnew.PCB_ARC):
            s, m, e = t.GetStart(), t.GetMid(), t.GetEnd()
            pts = [s, m, e]
        else:
            pts = [t.GetStart(), t.GetEnd()]
        for p0, p1 in zip(pts, pts[1:]):
            n = add(kind='trk', net=t.GetNetname(), layer=t.GetLayer(), s=p0, e=p1, w=w, trk=t,
                    bb=(min(p0.x, p1.x) - w // 2, min(p0.y, p1.y) - w // 2, max(p0.x, p1.x) + w // 2, max(p0.y, p1.y) + w // 2))
            tracks.append(n)
    for z in b.Zones():
        if z.GetIsRuleArea():
            continue
        for l in cu:
            if not z.IsOnLayer(l) or not z.HasFilledPolysForLayer(l):
                continue
            fl = z.GetFilledPolysList(l)
            for k in range(fl.OutlineCount()):
                isl = pcbnew.SHAPE_POLY_SET()
                isl.AddOutline(fl.Outline(k))
                for h in range(fl.HoleCount(k)):
                    isl.AddHole(fl.Hole(k, h))
                bb = isl.BBox()
                add(kind='zone', net=z.GetNetname(), layer=l, poly=isl, td=z.IsTeardropArea(),
                    bb=(bb.GetLeft(), bb.GetTop(), bb.GetRight(), bb.GetBottom()))

    # 空间网格（按 网络+层 分桶）
    grid = collections.defaultdict(list)
    for n in nodes:
        x0, y0, x1, y1 = n['bb']
        for gx in range(x0 // CELL, x1 // CELL + 1):
            for gy in range(y0 // CELL, y1 // CELL + 1):
                grid[(n['net'], n['layer'], gx, gy)].append(n['i'])

    par = list(range(len(nodes)))

    def f(x):
        while par[x] != x:
            par[x] = par[par[x]]
            x = par[x]
        return x

    def u(x, y):
        par[f(x)] = f(y)

    def dseg(p, s, e):
        dx, dy = e.x - s.x, e.y - s.y
        L = dx * dx + dy * dy
        t = 0 if L == 0 else max(0.0, min(1.0, ((p.x - s.x) * dx + (p.y - s.y) * dy) / L))
        return math.hypot(s.x + t * dx - p.x, s.y + t * dy - p.y)

    def inter(pa, pb):
        c = pcbnew.SHAPE_POLY_SET(pa)
        c.BooleanIntersection(pb)
        return c.Area() > 0

    def touches(A, B):
        ka, kb = A['kind'], B['kind']
        if ka > kb:
            A, B, ka, kb = B, A, kb, ka
        # 排序后：pad < trk < via < zone
        if (ka, kb) == ('pad', 'pad'):
            return inter(A['poly'], B['poly'])
        if (ka, kb) == ('pad', 'trk'):  # 走线端点落在焊盘里，或焊盘中心压在走线上
            return (A['poly'].Contains(B['s']) or A['poly'].Contains(B['e'])
                    or dseg(A['pad'].GetPosition(), B['s'], B['e']) <= B['w'] / 2)
        if (ka, kb) == ('pad', 'via'):
            return A['poly'].Collide(B['c'], B['r'])
        if (ka, kb) == ('pad', 'zone'):
            return inter(A['poly'], B['poly'])
        if (ka, kb) == ('trk', 'trk'):
            return (dseg(A['s'], B['s'], B['e']) <= B['w'] / 2 or dseg(A['e'], B['s'], B['e']) <= B['w'] / 2 or
                    dseg(B['s'], A['s'], A['e']) <= A['w'] / 2 or dseg(B['e'], A['s'], A['e']) <= A['w'] / 2)
        if (ka, kb) == ('trk', 'via'):
            return min(math.dist((A['s'].x, A['s'].y), (B['c'].x, B['c'].y)),
                       math.dist((A['e'].x, A['e'].y), (B['c'].x, B['c'].y))) <= B['r'] \
                or dseg(B['c'], A['s'], A['e']) <= A['w'] / 2  # 过孔骑在走线中段
        if (ka, kb) == ('trk', 'zone'):
            return B['poly'].Contains(A['s']) or B['poly'].Contains(A['e'])
        if (ka, kb) == ('via', 'via'):
            return math.dist((A['c'].x, A['c'].y), (B['c'].x, B['c'].y)) <= A['r'] + B['r']
        if (ka, kb) == ('via', 'zone'):
            return B['poly'].Collide(A['c'], A['r'])
        if (ka, kb) == ('zone', 'zone'):
            return inter(A['poly'], B['poly'])
        return False

    def bbov(p, q):
        return p[0] <= q[2] and q[0] <= p[2] and p[1] <= q[3] and q[1] <= p[3]

    seen = set()
    for key, ids in grid.items():
        if not key[0]:
            continue
        for ii in range(len(ids)):
            for jj in range(ii + 1, len(ids)):
                i, j = ids[ii], ids[jj]
                pk = (i, j) if i < j else (j, i)
                if pk in seen:
                    continue
                seen.add(pk)
                if f(i) == f(j) or not bbov(nodes[i]['bb'], nodes[j]['bb']):
                    continue
                if touches(nodes[i], nodes[j]):
                    u(i, j)
    # 同一焊盘/过孔在不同层上的节点本来就是一体的（通孔、过孔）
    first = {}
    for n in nodes:
        k = ('pad', n['name']) if n['kind'] == 'pad' else ('via', id(n['via'])) if n['kind'] == 'via' else None
        if k:
            if k in first:
                u(n['i'], first[k])
            else:
                first[k] = n['i']

    # 按网络统计焊盘分组
    pads_by_net = collections.defaultdict(dict)
    for n in nodes:
        if n['kind'] == 'pad' and n['net'] and not n['net'].startswith('unconnected-'):
            pads_by_net[n['net']][n['name']] = f(n['i'])
    bad = []
    mine_edges = 0
    for net, pm in sorted(pads_by_net.items()):
        if rx and not rx.search(net):
            continue
        groups = collections.defaultdict(list)
        for name, r in pm.items():
            groups[f(r)].append(name)
        if len(groups) > 1:
            mine_edges += len(groups) - 1
            bad.append(dict(net=net, pads=len(pm), groups=[sorted(g) for g in groups.values()]))

    # 悬空走线端点
    dangling = []
    for t in tracks:
        for end in ('s', 'e'):
            p = t[end]
            hit = False
            for gk in ((t['net'], t['layer'], p.x // CELL, p.y // CELL),):
                for j in grid.get(gk, []):
                    o = nodes[j]
                    if o is t:
                        continue
                    if o['kind'] == 'trk' and o['trk'] is t['trk']:
                        if (end == 's' and (o['e'].x, o['e'].y) == (p.x, p.y)) or (end == 'e' and (o['s'].x, o['s'].y) == (p.x, p.y)):
                            hit = True  # 同一圆弧拆成的两段相接
                        continue
                    if o['kind'] == 'pad' and o['pad'].HitTest(p, 0):
                        hit = True
                    elif o['kind'] == 'via' and math.dist((p.x, p.y), (o['c'].x, o['c'].y)) <= o['r']:
                        hit = True
                    elif o['kind'] == 'trk' and dseg(p, o['s'], o['e']) <= o['w'] / 2:
                        hit = True
                    elif o['kind'] == 'zone' and o['poly'].Contains(p):
                        hit = True
                    if hit:
                        break
            if not hit:
                dangling.append((t['net'], b.GetLayerName(t['layer']), round(mm(p.x), 3), round(mm(p.y), 3)))

    kicad_unc = b.GetConnectivity().GetUnconnectedCount(False)
    print(f'板子 {a.pcb}：节点 {len(nodes)}（焊盘层面/走线段/过孔层面/覆铜岛）')
    print(f'\n自写并查集：未布通网络 {len(bad)} 个，缺连接 {mine_edges} 条')
    for x in bad[:40]:
        print(f"   ❌ {x['net']}  焊盘 {x['pads']}  分成 {len(x['groups'])} 组")
        for g in x['groups'][:6]:
            print('        [' + ', '.join(g[:12]) + (' …' if len(g) > 12 else '') + ']')
    print(f'KiCad ratsnest：未连接 {kicad_unc} 条')
    if kicad_unc != mine_edges:
        print('   ⚠ 两个判据不一致 —— 先查清是哪一边错（覆铜是否已填充？圆弧/异形焊盘？），不许挑一个好看的用')
    else:
        print('   ✅ 两个判据一致')
    print(f'\n悬空走线端点 {len(dangling)} 个' + ('（删悬空段要“纯修剪”：只删不布，反复到收敛）' if dangling else ''))
    for d in dangling[:20]:
        print('     ', d)
    if a.json:
        json.dump(dict(unrouted=bad, mine_missing=mine_edges, kicad_unconnected=kicad_unc, dangling=dangling),
                  open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    sys.exit(1 if (bad or kicad_unc) else 0)


if __name__ == '__main__':
    main()
