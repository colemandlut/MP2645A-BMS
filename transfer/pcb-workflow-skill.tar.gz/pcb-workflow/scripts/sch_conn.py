#!/usr/bin/env python3
"""原理图连通性 / 悬空 / 同网多名（短路）检查 —— 规则 00 ⓪ ⓪b、闸口 A1 泳道。

用法：
    python3 sch_conn.py <root.kicad_sch> [--netlist net.xml] [--erc erc.json]
                        [--radius 5.08] [--show 'SW|SW7'] [--json out.json]

没给 --netlist / --erc 时自动调用 kicad-cli 生成（kicad-cli 需在 PATH 中；
chroot 版 kicad-cli 只能访问 /home/user 与 /tmp 下的文件）。

三个判据，按优先级（与 SKILL 规则 00 ⓪ 一致，**不许颠倒**）：
  ① KiCad 自己的 ERC（kicad-cli sch erc）             —— 权威
  ② 网表 XML（kicad-cli sch export netlist --format kicadxml）—— 交叉验证
  ③ 本脚本对 .kicad_sch 几何的并查集                  —— 只用来“指出死头在哪、该接回哪”
几何判据只是修复提示，**不能单独用来宣布“已连通”**。

输出的问题分级：
  [P0] 同网多名（两个不同网络名落在同一连通域 = 短路）、整颗器件全脚悬空、两脚件一脚悬空
  [P1] 引脚悬空（非 NC）、标签只连到一个脚、线头悬空（死头）
  [info] ERC 分类计数、--show 指定网络的成员（两路同构电路并排比对用）
退出码：有 P0 → 2；只有 P1 → 1；干净 → 0。
"""
import argparse, collections, json, math, os, re, subprocess, sys, tempfile
import xml.etree.ElementTree as ET

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kisexp as S  # noqa: E402

EPS = 1e-3  # mm

# ---------------------------------------------------------------- kicad-cli
def run_cli(args):
    r = subprocess.run(['kicad-cli'] + args, capture_output=True, text=True)
    if r.returncode not in (0, 5):  # 5 = --exit-code-violations 有违规
        sys.stderr.write(r.stdout + r.stderr)
        raise SystemExit('kicad-cli 失败: ' + ' '.join(args))
    return r.stdout


def auto_outputs(sch, a):
    # 中间文件不落在用户工程目录里（规则 00a）；/tmp 对 chroot 版 kicad-cli 也可访问
    tmp = tempfile.mkdtemp(prefix='schconn-', dir='/tmp' if os.path.isdir('/tmp') else None)
    if not a.netlist:
        a.netlist = os.path.join(tmp, 'netlist.xml')
        run_cli(['sch', 'export', 'netlist', '--format', 'kicadxml', '-o', a.netlist, sch])
    if not a.erc:
        a.erc = os.path.join(tmp, 'erc.json')
        run_cli(['sch', 'erc', '--format', 'json', '--severity-all', '-o', a.erc, sch])
    print(f'[自动生成] 网表 {a.netlist}\n[自动生成] ERC  {a.erc}')


# ---------------------------------------------------------------- ① ERC
CONN_TYPES = {
    'pin_not_connected': 'P1', 'wire_dangling': 'P1', 'unconnected_wire_endpoint': 'P1',
    'label_dangling': 'P1', 'global_label_dangling': 'P1', 'isolated_pin_label': 'P1',
    'multiple_net_names': 'P0', 'no_connect_connected': 'P0', 'pin_to_pin': 'P1',
    'hier_label_mismatch': 'P1', 'single_global_label': 'P1', 'similar_labels': 'P1',
    'similar_power': 'P1', 'similar_label_and_power': 'P1', 'power_pin_not_driven': 'P1',
    'pin_not_driven': 'P1', 'no_connect_dangling': 'P1', 'net_not_bus_member': 'P1',
    'bus_entry_needed': 'P1', 'endpoint_off_grid': 'info', 'duplicate_reference': 'P0',
}


def erc_report(path):
    d = json.load(open(path, encoding='utf-8'))
    cnt = collections.Counter()
    items = collections.defaultdict(list)
    for sh in d.get('sheets', []):
        for v in sh.get('violations', []):
            t = v.get('type', '?')
            cnt[t] += 1
            items[t].append((sh.get('path', ''), v.get('description', ''),
                             '; '.join(i.get('description', '') for i in v.get('items', []))))
    return cnt, items


# ---------------------------------------------------------------- ② 网表 XML
def load_netlist(path):
    root = ET.parse(path).getroot()
    comps = {}
    for c in root.iter('comp'):
        fields = {f.get('name'): (f.text or '') for f in c.iter('field')}
        comps[c.get('ref')] = dict(value=(c.findtext('value') or ''),
                                   footprint=(c.findtext('footprint') or ''), fields=fields)
    nets = {}
    for n in root.iter('net'):
        nets[n.get('name')] = [(x.get('ref'), x.get('pin'), x.get('pintype') or '',
                                x.get('pinfunction') or '') for x in n.iter('node')]
    return comps, nets


def netlist_checks(comps, nets):
    """并查集：节点 = 器件引脚；同网即合并。再从连通结构里挑出悬空、单点、器件自短路。"""
    parent = {}

    def f(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def u(a, b):
        parent[f(a)] = f(b)

    pin_net = {}
    for name, nodes in nets.items():
        for i, (ref, pin, *_r) in enumerate(nodes):
            pin_net[(ref, pin)] = name
            f((ref, pin))
            if i:
                u((ref, pin), (nodes[0][0], nodes[0][1]))
    size = collections.Counter(f(k) for k in pin_net)

    res = collections.defaultdict(list)
    by_ref = collections.defaultdict(list)
    ptype_of = {(r, p): t for nodes in nets.values() for r, p, t, _ in nodes}
    for (ref, pin), name in pin_net.items():
        by_ref[ref].append((pin, name))
    for name, nodes in nets.items():
        auto = name.startswith('unconnected-') or name.startswith('Net-(')
        base = name.rsplit('/', 1)[-1]
        if len(nodes) == 1:
            ref, pin, ptype, _pf = nodes[0]
            if 'no_connect' in ptype:
                continue  # 放了 NC 标记或本身就是 NC 脚：合理悬空
            if name.startswith('unconnected-'):
                res['pin_unconnected'].append(f'{ref}.{pin} ({ptype})')
            elif name.startswith('Net-('):
                res['wire_to_nowhere'].append(f'{ref}.{pin}：网络 {name} 只有这一个脚（线拉出去没接到任何东西）')
            elif not auto:
                res['label_single_pin'].append(f'{base}：只连到 {ref}.{pin}（标签/电源符号只落在一个脚上）')
    for ref, pins in sorted(by_ref.items()):
        real = [(p, n) for p, n in pins]
        unc = [p for p, n in real if size[f((ref, p))] == 1 and n.startswith('unconnected-')]
        unc_real = [p for p in unc if 'no_connect' not in ptype_of.get((ref, p), '')]
        if len(real) >= 2 and len(unc_real) == len(real):
            res['part_all_floating'].append(f'{ref}（{comps.get(ref, {}).get("value", "")}）全部 {len(real)} 脚悬空，等于这颗器件不存在')
        elif len(real) == 2 and len(unc_real) == 1:
            res['twopin_half_open'].append(f'{ref}（{comps.get(ref, {}).get("value", "")}）脚 {unc_real[0]} 悬空，两脚件只接了一端')
        if len(real) == 2 and real[0][1] == real[1][1] and not real[0][1].startswith('unconnected-'):
            res['twopin_shorted'].append(f'{ref} 两脚都在网络 {real[0][1]} 上（器件被自身短路）')
    return res


# ---------------------------------------------------------------- ③ 原理图几何并查集
def lib_pins(libsym):
    """lib_symbols 里一个符号的所有引脚：[(unit, body_style, number, x, y, type)]。"""
    out = []
    name = libsym[1]
    for sub in [libsym] + S.findall(libsym, 'symbol'):
        m = re.match(r'.*_(\d+)_(\d+)$', sub[1]) if sub is not libsym else None
        unit, style = (int(m.group(1)), int(m.group(2))) if m else (0, 0)
        for p in S.findall(sub, 'pin'):
            a = S.at(p)
            num = S.val(p, 'number', 1, '')
            out.append((unit, style, num, a[0], a[1], p[1] if len(p) > 1 else ''))
    return name, out


def xform(X, Y, rot, mirror, px, py):
    """库坐标(y 上正) -> 图纸绝对坐标(y 下正)。先转后镜像（与 KiCad 一致，已用 demo 实测）。"""
    dx, dy = px, -py
    r = int(round(rot)) % 360
    if r == 90:
        dx, dy = dy, -dx
    elif r == 180:
        dx, dy = -dx, -dy
    elif r == 270:
        dx, dy = -dy, dx
    if mirror == 'x':
        dy = -dy
    elif mirror == 'y':
        dx = -dx
    return round(X + dx, 4), round(Y + dy, 4)


def sheet_files(root_path):
    seen, order, st = set(), [], [os.path.abspath(root_path)]
    while st:
        p = st.pop()
        if p in seen or not os.path.exists(p):
            continue
        seen.add(p)
        order.append(p)
        for sh in S.walk(S.load(p), 'sheet'):
            fn = S.props(sh).get('Sheetfile') or S.props(sh).get('Sheet file')
            if fn:
                st.append(os.path.join(os.path.dirname(p), fn))
    return order


def on_seg(p, a, b):
    (x, y), (x1, y1), (x2, y2) = p, a, b
    if min(x1, x2) - EPS > x or x > max(x1, x2) + EPS or min(y1, y2) - EPS > y or y > max(y1, y2) + EPS:
        return False
    return abs((x2 - x1) * (y - y1) - (y2 - y1) * (x - x1)) <= EPS * max(1.0, math.hypot(x2 - x1, y2 - y1))


def geom_sheet(path):
    tree = S.load(path)
    libs = {}
    power_libs = set()
    ls = S.find(tree, 'lib_symbols')
    for sym in (S.findall(ls, 'symbol') if ls else []):
        nm, pins = lib_pins(sym)
        libs[nm] = pins
        if S.find(sym, 'power') is not None:
            power_libs.add(nm)
    items = []  # dict(kind, pt, ...)；导线另存
    wires = []
    for w in S.findall(tree, 'wire'):
        pts = [(float(x[1]), float(x[2])) for x in S.walk(w, 'xy')]
        for a, b in zip(pts, pts[1:]):
            wires.append((a, b))
    for j in S.findall(tree, 'junction'):
        x, y, _ = S.at(j); items.append(dict(kind='junction', pt=(x, y)))
    for n in S.findall(tree, 'no_connect'):
        x, y, _ = S.at(n); items.append(dict(kind='nc', pt=(x, y)))
    for kind in ('label', 'global_label', 'hierarchical_label'):
        for l in S.findall(tree, kind):
            x, y, _ = S.at(l); items.append(dict(kind=kind, name=l[1], pt=(x, y)))
    for sh in S.findall(tree, 'sheet'):
        for p in S.findall(sh, 'pin'):
            x, y, _ = S.at(p); items.append(dict(kind='sheetpin', name=p[1], pt=(x, y)))
    for sym in S.findall(tree, 'symbol'):
        lid = S.val(sym, 'lib_id')
        if lid is None or S.at(sym) is None:
            continue
        X, Y, rot = S.at(sym)
        mir = S.val(sym, 'mirror')
        unit = int(S.val(sym, 'unit', 1, 1))
        style = int(S.val(sym, 'body_style', 1, 0) or S.val(sym, 'convert', 1, 0) or 1)
        pr = S.props(sym)
        ref = pr.get('Reference', '?')
        is_flag = ref.startswith('#FLG') or lid.endswith('PWR_FLAG') or pr.get('Value') == 'PWR_FLAG'
        is_pwr = is_flag or lid in power_libs or ref.startswith('#PWR')
        for (u, st, num, px, py, ptype) in libs.get(lid, []):
            if u not in (0, unit) or st not in (0, style):
                continue
            pt = xform(X, Y, rot, mir, px, py)
            if is_pwr:
                if is_flag:
                    items.append(dict(kind='flag', pt=pt))
                else:
                    items.append(dict(kind='power', name=pr.get('Value', ''), pt=pt))
            else:
                items.append(dict(kind='pin', ref=ref, num=num, ptype=ptype, pt=pt))
    return items, wires


def geom_checks(path, radius):
    items, wires = geom_sheet(path)
    N = len(items) + len(wires)
    par = list(range(N))

    def f(x):
        while par[x] != x:
            par[x] = par[par[x]]
            x = par[x]
        return x

    def u(a, b):
        par[f(a)] = f(b)

    key = lambda p: (round(p[0], 3), round(p[1], 3))
    bucket = collections.defaultdict(list)  # 坐标 -> 节点
    for i, it in enumerate(items):
        bucket[key(it['pt'])].append(i)
    W0 = len(items)
    for k, (a, b) in enumerate(wires):
        bucket[key(a)].append(W0 + k)
        bucket[key(b)].append(W0 + k)
    for ids in bucket.values():
        for x in ids[1:]:
            u(ids[0], x)
    # 连接点落在导线中段也算连（标签/引脚/线端/结点）
    pts = list(bucket.keys())
    for k, (a, b) in enumerate(wires):
        for p in pts:
            if p != key(a) and p != key(b) and on_seg(p, a, b):
                for x in bucket[p]:
                    u(W0 + k, x)
    dom = collections.defaultdict(lambda: dict(names=set(), items=[]))
    for i, it in enumerate(items):
        d = dom[f(i)]
        d['items'].append(it)
        if it['kind'] in ('label', 'global_label', 'hierarchical_label', 'power') and it.get('name'):
            d['names'].add(it['name'])
    shorts = [sorted(d['names']) for d in dom.values() if len(d['names']) > 1]
    for d in dom.values():  # 与层次标签同域的局部标签，会被父图的名字改名，属正常
        hier = any(it['kind'] == 'hierarchical_label' for it in d['items'])
        for it in d['items']:
            it['hier_domain'] = hier

    # 死头：线端点，该坐标上只有这一个线端、没有任何引脚/标签/结点，也不落在别的线中段
    wire_on = collections.Counter()
    for k, (a, b) in enumerate(wires):
        wire_on[key(a)] += 1
        wire_on[key(b)] += 1
    item_at = collections.defaultdict(list)
    for it in items:
        item_at[key(it['pt'])].append(it)
    dead = []
    for k, (a, b) in enumerate(wires):
        for p in (key(a), key(b)):
            if wire_on[p] > 1 or item_at[p]:
                continue
            if any(on_seg(p, *w) for j, w in enumerate(wires) if j != k):
                continue
            dead.append(p)
    # 孤立引脚：坐标上没有线、没有别的东西、也不在任何线中段
    lonely = []
    for it in items:
        if it['kind'] != 'pin' or 'no_connect' in it['ptype']:
            continue
        p = key(it['pt'])
        others = [x for x in item_at[p] if x is not it]
        if wire_on[p] or others or any(on_seg(p, *w) for w in wires):
            continue
        lonely.append(it)
    pairs = []
    for it in lonely:
        best = None
        for q in dead:
            dd = math.dist(it['pt'], q)
            if dd <= radius and (best is None or dd < best[0]):
                best = (dd, q)
        if best:
            pairs.append((it, best))
    return dict(shorts=shorts, dead=dead, lonely=lonely, pairs=pairs,
                n_items=len(items), n_wires=len(wires), labels=[it for it in items if it.get('name') and it['kind'] != 'sheetpin'])


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('sch')
    ap.add_argument('--netlist')
    ap.add_argument('--erc')
    ap.add_argument('--radius', type=float, default=5.08, help='死头配对半径 mm（默认 5.08 = 4 格）')
    ap.add_argument('--show', help='正则：打印匹配网络的全部成员（同构电路并排比对）')
    ap.add_argument('--json')
    a = ap.parse_args()
    if not (a.netlist and a.erc):
        auto_outputs(a.sch, a)

    P0, P1 = [], []
    out = {}
    # ① ERC
    cnt, items = erc_report(a.erc)
    print('\n=== ① KiCad ERC（权威判据）===')
    if not cnt:
        print('   ERC 0 条')
    for t, n in cnt.most_common():
        lv = CONN_TYPES.get(t, 'info')
        print(f'   [{lv:4}] {t:28} {n}')
        if lv in ('P0', 'P1'):
            for sh, desc, it in items[t][:12]:
                print(f'          {sh} {desc} | {it}')
            if len(items[t]) > 12:
                print(f'          …还有 {len(items[t]) - 12} 条')
            (P0 if lv == 'P0' else P1).extend(f'ERC {t}: {d} | {i}' for _s, d, i in items[t])
    if cnt.get('footprint_link_issues') or cnt.get('lib_symbol_issues'):
        print('   ⚠ 有库链接类告警：多半是本机没配全局 fp/sym-lib-table（新容器常见），'
              '或只对子图单跑了 ERC —— 只认根图纸的结果')
    out['erc'] = dict(cnt)

    # ② 网表
    comps, nets = load_netlist(a.netlist)
    res = netlist_checks(comps, nets)
    print(f'\n=== ② 网表并查集（{len(comps)} 器件 / {len(nets)} 网络）===')
    lvl = dict(part_all_floating='P0', twopin_half_open='P0', twopin_shorted='P0',
               pin_unconnected='P1', wire_to_nowhere='P1', label_single_pin='P1')
    title = dict(part_all_floating='整颗器件全脚悬空', twopin_half_open='两脚件一端悬空',
                 twopin_shorted='两脚件自短路', pin_unconnected='引脚悬空（未放 NC 标记）',
                 wire_to_nowhere='线拉出去没接东西', label_single_pin='网络名只挂一个脚')
    for k in lvl:
        v = res.get(k, [])
        print(f'   [{lvl[k]}] {title[k]}：{len(v)}')
        for x in v[:20]:
            print('          ' + x)
        if len(v) > 20:
            print(f'          …还有 {len(v) - 20} 条')
        (P0 if lvl[k] == 'P0' else P1).extend(f'{title[k]}: {x}' for x in v)
    print('   ⚠ 真正的空脚不要当错：IC 未用通道、MCU 未用 GPIO、USB-C 未用脚、稳压器 NC 脚 —— '
          '正确做法是在图上放「不连接」标记(NC)，放了就不会再报')
    out['netlist'] = {k: v for k, v in res.items()}

    # ③ 几何
    print('\n=== ③ 原理图几何并查集（只作修复提示，不作连通判据）===')
    all_labels = set()
    geo = {}
    for p in sheet_files(a.sch):
        g = geom_checks(p, a.radius)
        geo[os.path.basename(p)] = g
        # 层次标签在父图里会被图纸引脚改名，属正常，不参与“名字消失”判据
        all_labels |= {it['name'] for it in g['labels']
                       if it['kind'] != 'hierarchical_label' and not it.get('hier_domain')}
        print(f'   {os.path.basename(p)}：图元 {g["n_items"]}，导线段 {g["n_wires"]}，'
              f'同网多名 {len(g["shorts"])}，死头 {len(g["dead"])}，孤立引脚 {len(g["lonely"])}')
        for s in g['shorts']:
            print(f'      [P0] 同一连通域挂了多个网络名 {s} —— 短路（或误把两个网络并了）')
            P0.append(f'{os.path.basename(p)} 同网多名 {s}')
        for it, (dd, q) in g['pairs']:
            print(f'      [P1] 死头配对：{it["ref"]}.{it["num"]} @({it["pt"][0]:.2f},{it["pt"][1]:.2f}) '
                  f'← 最近死头 ({q[0]:.2f},{q[1]:.2f}) 距 {dd:.2f}mm —— 换符号/移件后引脚跑了、线没跟着走')
        for q in g['dead'][:15]:
            print(f'      死头 ({q[0]:.2f},{q[1]:.2f})')
    # 标签名在网表里消失 = 被别的名字吞了（短路）或者根本没连上
    def present(lbl):
        l = lbl.replace('{slash}', '/')
        return any(n == l or n.endswith('/' + l) for n in nets)
    swallowed = sorted(n for n in all_labels if not present(n))
    print(f'   图上网络名 {len(all_labels)} 个，网表里找不到的 {len(swallowed)} 个')
    for n in swallowed:
        print(f'      [P0] 「{n}」不在网表里：被同一连通域上的另一个名字吞掉（短路），或该标签根本没接上')
        P0.append(f'网络名消失 {n}')
    out['geometry'] = {k: dict(shorts=v['shorts'], dead=v['dead'],
                              pairs=[(f"{i['ref']}.{i['num']}", d) for i, d in v['pairs']]) for k, v in geo.items()}
    out['swallowed'] = swallowed

    if a.show:
        rx = re.compile(a.show)
        print('\n=== 指定网络成员（同构电路对照：不对称八成是漏件）===')
        for n in sorted(nets):
            if rx.search(n.rsplit('/', 1)[-1]):
                print(f'   {n:28} = {{' + ', '.join(f'{r}.{p}' for r, p, *_ in nets[n]) + '}')

    print(f'\n汇总：P0 = {len(P0)}，P1 = {len(P1)}   （判据优先级：ERC > 网表/PCB 焊盘网络 > 本脚本几何）')
    if a.json:
        out['P0'], out['P1'] = P0, P1
        json.dump(out, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    sys.exit(2 if P0 else 1 if P1 else 0)


if __name__ == '__main__':
    main()
