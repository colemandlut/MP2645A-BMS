#!/usr/bin/env python3
"""跑 KiCad DRC 并按“根因”聚类汇总 —— 规则 2 第 3 步、闸口 B5。

    python3 drc_report.py board.kicad_pcb [--no-refill] [--no-parity] [--json-out drc.json]
    python3 drc_report.py --from drc.json            # 只汇总已有报告

默认执行：kicad-cli pcb drc --format json --severity-all --refill-zones --schematic-parity
（--refill-zones 不加 --save-board，不改板子文件；chroot 版 kicad-cli 只能访问 /home/user 与 /tmp）

输出：
  - 按类型/严重度计数，未连接数，原理图一致性（parity）问题数
  - 🔴 被 .kicad_pro 设成 ignore 的检查项 —— “DRC=0” 可能只是因为关掉了检查（实测 demo 工程
    把 courtyards_overlap 设成 ignore，DRC 报 0，打开后 45 条）。验收前必须逐项确认这些 ignore 是有意的
  - 按涉及的位号/网络聚类：DRC 分类数 ≠ 根因数，先聚类再动手
退出码：有 error 级违规或未连接 → 1。
"""
import argparse, collections, json, os, re, subprocess, sys, tempfile

MUST_ON = {'courtyards_overlap', 'silk_overlap', 'silk_over_copper', 'copper_edge_clearance', 'clearance',
           'hole_clearance', 'hole_to_hole', 'annular_width', 'drill_out_of_range', 'track_width',
           'via_diameter', 'unconnected_items', 'shorting_items', 'items_not_allowed', 'text_height',
           'text_thickness', 'missing_courtyard', 'npth_inside_courtyard', 'pth_inside_courtyard',
           'malformed_courtyard', 'solder_mask_bridge', 'starved_thermal', 'footprint_type_mismatch',
           'lib_footprint_mismatch', 'duplicate_footprints', 'extra_footprint', 'missing_footprint',
           'net_conflict', 'schematic_parity'}


def refs_of(desc):
    """从条目描述里抠位号/网络：'Footprint D4'、'Pad 2 [GND] of R1 on F.Cu'、'Track [/U3D-] on F.Cu'。"""
    out = set(re.findall(r'Footprint (\S+)', desc)) | set(re.findall(r'\bof (\S+)', desc))
    if not out:
        out = {'网络 ' + n for n in re.findall(r'\[([^\]]+)\]', desc)}
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('pcb', nargs='?')
    ap.add_argument('--from', dest='src')
    ap.add_argument('--no-refill', action='store_true')
    ap.add_argument('--no-parity', action='store_true')
    ap.add_argument('--json-out')
    a = ap.parse_args()
    if a.src:
        path = a.src
    else:
        if not a.pcb:
            ap.error('需要 board.kicad_pcb 或 --from')
        path = a.json_out or os.path.join(tempfile.mkdtemp(prefix='drc-', dir='/tmp' if os.path.isdir('/tmp') else None), 'drc.json')
        cmd = ['kicad-cli', 'pcb', 'drc', '--format', 'json', '--severity-all', '-o', path]
        if not a.no_refill:
            cmd.append('--refill-zones')
        if not a.no_parity:
            cmd.append('--schematic-parity')
        r = subprocess.run(cmd + [a.pcb], capture_output=True, text=True)
        if not os.path.exists(path):
            sys.stderr.write(r.stdout + r.stderr)
            raise SystemExit('kicad-cli pcb drc 失败')
        print('$ ' + ' '.join(cmd + [a.pcb]))
    d = json.load(open(path, encoding='utf-8'))
    V = d.get('violations', [])
    U = d.get('unconnected_items', [])
    P = d.get('schematic_parity', [])
    ign = [x.get('key') for x in d.get('ignored_checks', [])]
    cnt = collections.Counter((v.get('severity'), v.get('type')) for v in V)
    print(f'报告 {path}（KiCad {d.get("kicad_version", "?")}）')
    print(f'违规 {len(V)}，未连接 {len(U)}，原理图一致性 {len(P)}')
    for (sev, t), n in sorted(cnt.items(), key=lambda kv: (kv[0][0] != 'error', -kv[1])):
        print(f'   [{sev:7}] {t:32} {n}')
    risky = [k for k in ign if k in MUST_ON]
    if ign:
        print(f'\n🔴 被设成 ignore 的检查 {len(ign)} 项' + (f'，其中必须确认的 {len(risky)} 项：{risky}' if risky else '：' + str(ign)))
        print('   → 「电路板配置 → 设计规则 → 违规严重级别」(Board Setup → Violation Severity) 里逐项核对；验收前把这些临时改成 error 跑一遍')
    # 聚类
    cl = collections.defaultdict(list)
    for v in V + U:
        keys = set()
        for it in v.get('items', []):
            keys |= refs_of(it.get('description', ''))
        for k in (keys or {'(无位号)'}):
            cl[k].append(v.get('type'))
    if cl:
        print(f'\n按涉及对象计数（出现次数最多的往往就是根因；DRC 条数 ≠ 根因数，先聚类再动手）')
        for k, ts in sorted(cl.items(), key=lambda kv: -len(kv[1]))[:20]:
            print(f'   {k:28} {len(ts):4} 条  {dict(collections.Counter(ts))}')
    for p in P[:20]:
        print('   parity:', p.get('type'), '|', p.get('description'), '|',
              '; '.join(i.get('description', '') for i in p.get('items', [])))
    bad = sum(n for (sev, _t), n in cnt.items() if sev == 'error') + len(U) + len(P)
    sys.exit(1 if bad else 0)


if __name__ == '__main__':
    main()
