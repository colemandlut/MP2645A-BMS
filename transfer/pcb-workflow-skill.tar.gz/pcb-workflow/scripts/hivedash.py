#!/usr/bin/env python3
"""PCB hive 仪表盘：读 hive 状态 + 三阶段产出清单，生成一张自包含 HTML。

用法:
    python3 hivedash.py                      # 默认 ~/ColemanOffice + ~/Developer/MunderDifflin
    python3 hivedash.py --hive DIR --work DIR --out FILE

产出是静态 HTML，没有外部依赖，双击就能看。判据一律以**文件是否存在**为准，
不采信任何 agent 的自述——这是本 skill 的铁律在进度跟踪上的同一张脸。
"""
import argparse, glob, json, os, re, sys, html, datetime, collections

def read_jsonl(p):
    out = []
    try:
        with open(p, encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    try: out.append(json.loads(line))
                    except Exception: pass
    except OSError: pass
    return out

def read_json(p, default=None):
    try:
        with open(p, encoding='utf-8') as f: return json.load(f)
    except Exception: return default if default is not None else {}

def ts(ms):
    try: return datetime.datetime.fromtimestamp(ms/1000).strftime('%m-%d %H:%M')
    except Exception: return '—'

def ago(sec):
    if sec is None: return '—'
    if sec < 90: return f'{int(sec)} 秒前'
    if sec < 5400: return f'{int(sec//60)} 分前'
    return f'{sec//3600} 小时前'

# ── 三阶段产出清单：(阶段, [(标题, glob 模式列表, 说明)]) ────────────────────
STAGES = [
    ('阶段 0 · 方案', 'gate0', [
        ('需求指标表',   ['**/req.md', '**/需求*.md'],            '输入/输出/功率/频率/负载/环境'),
        ('候选方案',     ['**/candidate*.md', '**/候选*.md'],      '≥2 个不同拓扑才算竞标'),
        ('横评矩阵',     ['**/tradeoff*.md', '**/横评*.md'],       '效率·成本·面积·风险·可采购性'),
        ('接口契约',     ['**/contract*.md', '**/契约*.md'],       '块间网络名·电平·协议（冻结后不许本地改）'),
        ('电源树',       ['**/power-tree*.md', '**/电源树*.md'],   '各支路电流与裕量'),
        ('闸口 0 报告',  ['**/C[1-4]-*.md', '**/*gate0*.md'],      'C1 需求覆盖 / C2 功率 / C3 接口 / C4 采购'),
    ]),
    ('阶段 A · 原理图', 'gateA', [
        ('原理图工程',   ['**/*.kicad_sch'],                       '层次根图 + 子图（只用 KiCad）'),
        ('生成脚本',     ['**/gen_*.py'],                          '图纸必须是幂等脚本的产物'),
        ('ERC',          ['**/*erc*.json', '**/*erc*.rpt', '**/*erc*.txt'], 'kicad-cli sch erc：判引脚悬空的权威判据'),
        ('网表',         ['**/netlist*.xml', '**/*.kicadxml', '**/net*.xml'], 'sch_conn.py 并查集的输入'),
        ('BOM',          ['**/*BOM*.csv', '**/*bom*.csv', '**/*BOM*.xlsx'], '原理图侧 vs PCB 侧 bomdiff 必须为 0'),
        ('闸口 A 快照',  ['**/snapshots/A-*', '**/review/A-*'],    '冻结目录，写完不再改'),
        ('A 泳道报告',   ['**/A[1-5]-*.md'],                       '五条泳道 + 覆盖清单'),
        ('复核报告',     ['**/*review*.md'],                        '换厂商模型，第 6 条泳道'),
        ('汇总 MERGED',  ['**/MERGED*.md'],                        '去重后的 P0/P1/P2'),
    ]),
    ('阶段 B · PCB', 'gateB', [
        ('PCB 工程',     ['**/*.kicad_pcb'],                       '单写，禁并发'),
        ('布局候选',     ['**/layout_*.py', '**/布局*.md'],        'N 版并行出方案'),
        ('DSN / SES',    ['**/*.dsn', '**/*.ses'],                 'Freerouting 往返'),
        ('DRC 报告',     ['**/drc*.json', '**/*drc*.rpt'],         'kicad-cli pcb drc --refill-zones --schematic-parity'),
        ('脚本判据',     ['**/pcb_conn*', '**/pcb_check*', '**/gerber_check*', '**/sch_conn*'], 'pcb_conn/pcb_check/gerber_check 必须全 0'),
        ('Gerber',       ['**/*GERBER*.zip', '**/gerber/**'],      '送审的必须是准备提交的那一份'),
        ('闸口 B 快照',  ['**/snapshots/B-*', '**/review/B-*'],    '解开的 Gerber + 脚本输出'),
        ('B 泳道报告',   ['**/B[1-5]-*.md'],                       '五条泳道 + 覆盖清单'),
        ('下单自检',     ['**/下单*.md', '**/order*.md', '**/fab*.md'], '逐字核对文件名（人工闸）'),
    ]),
]

def scan(workdirs, patterns):
    hits = []
    for d in workdirs:
        for pat in patterns:
            for p in glob.glob(os.path.join(d, pat), recursive=True):
                if '/.git/' in p or '/node_modules/' in p or '/.claude/' in p: continue
                hits.append(p)
    return sorted(set(hits))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--hive', default=os.path.expanduser('~/ColemanOffice/hive'))
    ap.add_argument('--work', default=os.path.expanduser('~/Developer/MunderDifflin'))
    ap.add_argument('--out',  default=os.path.expanduser('~/Developer/MunderDifflin/hive-dashboard.html'))
    a = ap.parse_args()

    workdirs = sorted(d for d in glob.glob(os.path.join(a.work, '*')) if os.path.isdir(d))
    fleet    = read_json(os.path.join(a.hive, 'fleet.json'), {})
    registry = read_json(os.path.join(a.hive, 'registry.json'), {})
    tasks    = read_json(os.path.join(a.hive, 'tasks.json'), {})
    log      = read_jsonl(os.path.join(a.hive, 'log.jsonl'))
    ledger   = read_jsonl(os.path.join(a.hive, 'cost-ledger.jsonl'))

    # 成本：去重（MD 每次重启会把整段会话重记一遍，原始总额虚高）
    seen, uniq = set(), []
    for r in ledger:
        k = (r.get('ts'), r.get('agent_id'), r.get('input'), r.get('output'), r.get('cache_read'), r.get('model'))
        if k in seen: continue
        seen.add(k); uniq.append(r)
    raw_usd  = sum(r.get('usd', 0) for r in ledger)
    real_usd = sum(r.get('usd', 0) for r in uniq)
    by_agent = collections.defaultdict(float)
    for r in uniq: by_agent[(r.get('agent_id'), r.get('model'))] += r.get('usd', 0)

    reg_items = registry.get('agents', registry)
    reg_items = list(reg_items.values()) if isinstance(reg_items, dict) else list(reg_items)
    reg_by_id = {o.get('id'): o for o in reg_items if isinstance(o, dict)}

    # 邮箱实绩：.sent 计数是「真的发出过」的唯一证据
    mail = {}
    for d in glob.glob(os.path.join(a.hive, 'agents', '*')):
        aid = os.path.basename(d)
        mail[aid] = {
            'sent':   len(glob.glob(os.path.join(d, 'outbox', '.sent', '*'))),
            'done':   len(glob.glob(os.path.join(d, 'inbox', '.done', '*'))),
            'unread': len(glob.glob(os.path.join(d, 'inbox', '*.json'))),
        }

    t_items = tasks.get('tasks', tasks)
    t_items = list(t_items.values()) if isinstance(t_items, dict) else list(t_items)

    E = html.escape
    P = []
    P.append(f"""<title>PCB hive 仪表盘</title><style>
:root{{--bg:#faf9f7;--card:#fff;--ink:#1c1b1a;--dim:#6b6a67;--line:#e2e0da;--ok:#1d9e75;--no:#b4b2a9;--warn:#ba7517;--bad:#e24b4a;--acc:#7f77dd}}
@media(prefers-color-scheme:dark){{:root{{--bg:#17161a;--card:#201f24;--ink:#eceaf0;--dim:#9b99a3;--line:#333139;--ok:#5dcaa5;--no:#5f5e5a;--warn:#efa027;--bad:#f09595}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:14px/1.6 -apple-system,"PingFang SC",system-ui,sans-serif}}
.wrap{{max-width:1080px;margin:0 auto;padding:28px 20px 60px}}
h1{{font-size:20px;font-weight:600;margin:0 0 4px}}h2{{font-size:15px;font-weight:600;margin:30px 0 10px}}
.sub{{color:var(--dim);font-size:12px;margin-bottom:22px}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin-bottom:12px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px}}
table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top}}
th{{color:var(--dim);font-weight:500;font-size:12px}}
.dot{{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:7px;vertical-align:1px}}
.pill{{display:inline-block;padding:1px 8px;border-radius:20px;font-size:11px;border:1px solid var(--line);color:var(--dim)}}
.bar{{height:6px;background:var(--line);border-radius:4px;overflow:hidden;margin-top:8px}}.bar>i{{display:block;height:100%;background:var(--ok)}}
.mono{{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;color:var(--dim);word-break:break-all}}
.miss{{color:var(--no)}}.hit{{color:var(--ok)}}
.stagehead{{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:8px}}
.big{{font-size:22px;font-weight:600}}
</style><div class="wrap">
<h1>PCB hive 仪表盘</h1>
<div class="sub">生成于 {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} · hive={E(a.hive)} · 工作区 {len(workdirs)} 个<br>
判据一律以<b>文件是否存在</b>为准，不采信 agent 的自述。</div>""")

    # ── 三阶段进度 ──
    P.append('<h2>三阶段产出</h2>')
    for name, key, items in STAGES:
        rows, have = [], 0
        for title, pats, note in items:
            hits = scan(workdirs, pats)
            ok = bool(hits)
            have += ok
            sample = ''
            if hits:
                rel = [os.path.relpath(h, a.work) for h in hits[:3]]
                sample = '<div class="mono">' + E(' · '.join(rel)) + (f' … 共 {len(hits)}' if len(hits) > 3 else '') + '</div>'
            rows.append(
                f'<tr><td style="width:130px"><span class="dot" style="background:{"var(--ok)" if ok else "var(--no)"}"></span>'
                f'<span class="{"hit" if ok else "miss"}">{E(title)}</span></td>'
                f'<td>{E(note)}{sample}</td></tr>')
        pct = int(have / len(items) * 100)
        P.append(f'''<div class="card"><div class="stagehead"><b>{E(name)}</b>
<span class="pill">{have} / {len(items)}</span></div>
<div class="bar"><i style="width:{pct}%"></i></div>
<table>{''.join(rows)}</table></div>''')

    # ── 坐席 ──
    P.append('<h2>坐席</h2><div class="card"><table><tr><th>名字</th><th>状态</th><th>最后活跃</th><th>发出</th><th>已处理</th><th>未读</th><th>归档</th></tr>')
    for o in fleet.get('agents', []):
        aid = o.get('id'); m = mail.get(aid, {})
        r = reg_by_id.get(aid, {})
        arch = r.get('archived')
        unread = m.get('unread', 0)
        P.append(f'''<tr><td><b>{E(str(o.get("name","")))}</b></td>
<td><span class="pill">{E(str(o.get("breaker","")))}</span></td>
<td>{E(ago(o.get("lastActiveSecAgo")))}</td>
<td>{m.get("sent",0)}</td><td>{m.get("done",0)}</td>
<td style="color:{'var(--bad)' if unread else 'inherit'}">{unread}</td>
<td>{'是' if arch else ''}</td></tr>''')
    # fleet 里没有但 registry 里有的（归档的坐席）
    fleet_ids = {o.get('id') for o in fleet.get('agents', [])}
    for o in reg_items:
        if o.get('id') in fleet_ids: continue
        m = mail.get(o.get('id'), {})
        P.append(f'''<tr><td><b>{E(str(o.get("name","")))}</b></td><td><span class="pill">离线</span></td>
<td>—</td><td>{m.get("sent",0)}</td><td>{m.get("done",0)}</td>
<td style="color:{'var(--bad)' if m.get("unread") else 'inherit'}">{m.get("unread",0)}</td>
<td>{'是' if o.get('archived') else ''}</td></tr>''')
    P.append('</table></div>')

    # ── 任务 ──
    if t_items:
        P.append('<h2>任务看板</h2><div class="card"><table><tr><th style="width:80px">状态</th><th>标题</th></tr>')
        order = {'doing': 0, 'blocked': 1, 'todo': 2, 'done': 3}
        for o in sorted([x for x in t_items if isinstance(x, dict)], key=lambda x: order.get(str(x.get('status')), 9)):
            st = str(o.get('status', ''))
            c = {'blocked': 'var(--bad)', 'doing': 'var(--warn)', 'done': 'var(--no)'}.get(st, 'var(--dim)')
            P.append(f'<tr><td><span class="pill" style="color:{c}">{E(st)}</span></td><td>{E(str(o.get("title","")))}</td></tr>')
        P.append('</table></div>')

    # ── 花费 ──
    P.append(f'''<h2>花费</h2><div class="grid">
<div class="card"><div class="sub" style="margin:0">去重后真实花费</div><div class="big">${real_usd:.2f}</div></div>
<div class="card"><div class="sub" style="margin:0">账本原始总额（含重复记账）</div><div class="big" style="color:var(--dim)">${raw_usd:.2f}</div>
<div class="sub" style="margin:6px 0 0">MD 每次「重启并继续」会把整段会话重记一遍，原始值虚高</div></div></div>
<div class="card"><table><tr><th>坐席</th><th>模型</th><th style="text-align:right">花费</th></tr>''')
    for (aid, model), usd in sorted(by_agent.items(), key=lambda x: -x[1]):
        if usd <= 0: continue
        nm = reg_by_id.get(aid, {}).get('name', aid)
        P.append(f'<tr><td>{E(str(nm))}</td><td class="mono">{E(str(model))}</td><td style="text-align:right">${usd:.2f}</td></tr>')
    P.append('</table></div>')

    # ── 近期消息 ──
    msgs = [d for d in log if d.get('kind') == 'message'][-14:]
    if msgs:
        P.append('<h2>近期消息</h2><div class="card"><table><tr><th style="width:86px">时间</th><th style="width:200px">路径</th><th>主题</th></tr>')
        for d in reversed(msgs):
            f_ = reg_by_id.get(d.get('from'), {}).get('name', d.get('from'))
            t_ = reg_by_id.get(d.get('to'), {}).get('name', d.get('to'))
            P.append(f'<tr><td class="mono">{E(ts(d.get("ts",0)))}</td>'
                     f'<td class="mono">{E(str(f_))} → {E(str(t_))}</td>'
                     f'<td>{E(str(d.get("subject","")))}</td></tr>')
        P.append('</table></div>')

    P.append('</div>')
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, 'w', encoding='utf-8') as f:
        f.write('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' + ''.join(P))
    print(f'→ {a.out}')

if __name__ == '__main__':
    main()
