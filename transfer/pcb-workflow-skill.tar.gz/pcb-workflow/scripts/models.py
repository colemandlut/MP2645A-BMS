#!/usr/bin/env python3
"""pcb-workflow 模型分工：查看 / 切换配置档 / 修改角色（配置在 ../models.toml）。

  python3 models.py show                       # 当前生效分工 + 启动器可用性 + 规则 00c 校验
  python3 models.py get draw                   # 只打印某角色（给脚本/任务书用），未配置则退出码 2
  python3 models.py cmd draw TASK.md OUT.md    # 打印展开后的启动命令（codex 类）
  python3 models.py use cloud                  # 本机切换配置档（写 ~/.config/pcb-workflow/profile）
  python3 models.py set cloud draw opus --vendor anthropic --launcher agent [--cmd ...] [--fallback a,b]
  python3 models.py profiles                   # 列出全部配置档

退出码：0 正常；1 规则校验不过（draw 与 review 同厂商 / 启动器不可用）；2 角色未配置。
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import sys
import tomllib

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.normpath(os.path.join(HERE, "..", "models.toml"))
LOCAL = os.path.expanduser("~/.config/pcb-workflow/profile")
ROLES = ["draw", "review", "lanes", "parts", "tool"]
ROLE_CN = {"draw": "画图/改图", "review": "独立复核", "lanes": "五维泳道",
           "parts": "取库/选料", "tool": "跑工具"}


def load() -> dict:
    with open(CFG, "rb") as fp:
        return tomllib.load(fp)


def active_profile(cfg: dict) -> tuple[str, str]:
    env = os.environ.get("PCB_MODEL_PROFILE", "").strip()
    if env:
        return env, "环境变量 PCB_MODEL_PROFILE"
    if os.path.isfile(LOCAL):
        name = open(LOCAL).read().strip()
        if name:
            return name, LOCAL
    return cfg.get("active", ""), "models.toml 的 active"


def role(cfg: dict, prof: str, r: str) -> dict:
    return cfg.get("profiles", {}).get(prof, {}).get(r, {}) or {}


def launcher_ok(rc: dict) -> tuple[bool, str]:
    ln = rc.get("launcher", "")
    if ln in ("agent", "main"):
        return True, "Claude Code 内置"
    if ln == "codex":
        p = shutil.which("codex")
        return (p is not None), (p or "未找到 codex CLI")
    if not ln:
        return False, "未配置"
    return shutil.which(ln) is not None, shutil.which(ln) or f"未找到 {ln}"


def validate(cfg: dict, prof: str) -> list[str]:
    errs = []
    d, v = role(cfg, prof, "draw"), role(cfg, prof, "review")
    for r in ROLES:
        rc = role(cfg, prof, r)
        if not rc.get("model"):
            errs.append(f"{r}（{ROLE_CN[r]}）未配置模型")
            continue
        ok, why = launcher_ok(rc)
        if not ok:
            errs.append(f"{r}（{ROLE_CN[r]}）启动器不可用：{why}")
    if d.get("vendor") and v.get("vendor") and d["vendor"] == v["vendor"]:
        errs.append(f"规则 00c：画图（{d['model']}）与复核（{v['model']}）同为 {d['vendor']}，必须不同厂商")
    return errs


def cmd_show(cfg, _a):
    prof, src = active_profile(cfg)
    if prof not in cfg.get("profiles", {}):
        print(f"❌ 配置档 {prof!r} 不存在（来源：{src}）")
        return 2
    print(f"配置文件：{CFG}")
    print(f"当前配置档：{prof}（来源：{src}）")
    note = cfg["profiles"][prof].get("note")
    if note:
        print(f"说明：{note}")
    print()
    print(f"{'角色':<8}{'用途':<10}{'模型':<16}{'厂商':<11}{'启动器':<8}{'可用':<4}回退")
    for r in ROLES:
        rc = role(cfg, prof, r)
        ok, why = launcher_ok(rc)
        print(f"{r:<8}{ROLE_CN[r]:<8}{rc.get('model') or '(未配置)':<16}{rc.get('vendor') or '-':<11}"
              f"{rc.get('launcher') or '-':<8}{'✅' if ok else '❌':<4}{','.join(rc.get('fallback', [])) or '-'}")
    errs = validate(cfg, prof)
    print()
    if errs:
        for e in errs:
            print("⚠", e)
        return 1
    print("✅ 规则 00c 校验通过（画图与复核不同厂商，启动器均可用）")
    return 0


def cmd_get(cfg, a):
    prof, _ = active_profile(cfg)
    rc = role(cfg, prof, a.role)
    if not rc.get("model"):
        print(f"{a.role} 在配置档 {prof} 中未配置", file=sys.stderr)
        return 2
    print(f"model={rc['model']} vendor={rc.get('vendor', '')} launcher={rc.get('launcher', '')}")
    return 0


def cmd_cmd(cfg, a):
    prof, _ = active_profile(cfg)
    rc = role(cfg, prof, a.role)
    if not rc.get("cmd"):
        print(f"{a.role} 没有 cmd（launcher={rc.get('launcher')!r}，用 Agent 工具 model={rc.get('model')!r}）",
              file=sys.stderr)
        return 2
    print(rc["cmd"].format(model=rc["model"], task=a.task, out=a.out))
    return 0


def cmd_use(cfg, a):
    if a.profile not in cfg.get("profiles", {}):
        print(f"配置档 {a.profile!r} 不存在；现有：{', '.join(cfg.get('profiles', {}))}")
        return 2
    os.makedirs(os.path.dirname(LOCAL), exist_ok=True)
    with open(LOCAL, "w") as fp:
        fp.write(a.profile + "\n")
    print(f"本机已切换到 {a.profile}（写入 {LOCAL}）")
    return cmd_show(load(), a)


def _toml_str(s: str) -> str:
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def cmd_set(cfg, a):
    """就地改写 models.toml 中 [profiles.<p>.<r>] 段，保留注释和其它段。"""
    text = open(CFG).read()
    hdr = f"[profiles.{a.profile}.{a.role}]"
    fields = {"model": a.model}
    if a.vendor is not None:
        fields["vendor"] = a.vendor
    if a.launcher is not None:
        fields["launcher"] = a.launcher
    if a.cmd is not None:
        fields["cmd"] = a.cmd
    if a.fallback is not None:
        fields["fallback"] = [x for x in a.fallback.split(",") if x]

    def render(k, v):
        if isinstance(v, list):
            return f"{k} = [" + ", ".join(_toml_str(x) for x in v) + "]"
        return f"{k} = {_toml_str(v)}"

    m = re.search(r"^([ \t]*)" + re.escape(hdr) + r"[^\n]*\n", text, re.M)
    if not m:
        if f"[profiles.{a.profile}]" not in text:
            text += f"\n[profiles.{a.profile}]\nnote = \"\"\n"
        text += f"\n  {hdr}\n" + "".join(f"  {render(k, v)}\n" for k, v in fields.items())
    else:
        indent = m.group(1)
        start = m.end()
        nxt = re.search(r"^\s*\[", text[start:], re.M)
        end = start + (nxt.start() if nxt else len(text) - start)
        body = text[start:end]
        for k, v in fields.items():
            line = f"{indent}{render(k, v)}"
            pat = re.compile(r"^[ \t]*" + k + r"\s*=.*$", re.M)
            body = pat.sub(lambda _m: line, body, count=1) if pat.search(body) else line + "\n" + body
        text = text[:start] + body + text[end:]
    tomllib.loads(text)                      # 写之前先确认仍是合法 TOML
    with open(CFG, "w") as fp:
        fp.write(text)
    print(f"已更新 {hdr}：{fields}")
    return cmd_show(load(), a)


def cmd_profiles(cfg, _a):
    prof, _ = active_profile(cfg)
    for name, p in cfg.get("profiles", {}).items():
        print(f"{'*' if name == prof else ' '} {name:<12} {p.get('note', '')}")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="op", required=True)
    sub.add_parser("show")
    sub.add_parser("profiles")
    g = sub.add_parser("get"); g.add_argument("role", choices=ROLES)
    c = sub.add_parser("cmd"); c.add_argument("role", choices=ROLES); c.add_argument("task"); c.add_argument("out")
    u = sub.add_parser("use"); u.add_argument("profile")
    s = sub.add_parser("set")
    s.add_argument("profile"); s.add_argument("role", choices=ROLES); s.add_argument("model")
    s.add_argument("--vendor"); s.add_argument("--launcher"); s.add_argument("--cmd"); s.add_argument("--fallback")
    a = ap.parse_args(argv)
    cfg = load()
    return {"show": cmd_show, "profiles": cmd_profiles, "get": cmd_get, "cmd": cmd_cmd,
            "use": cmd_use, "set": cmd_set}[a.op](cfg, a)


if __name__ == "__main__":
    sys.exit(main())
