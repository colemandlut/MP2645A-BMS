#!/usr/bin/env python3
"""下单前的制造文件自检（读文件本身，不信 DRC、不信文件名）—— 规则 2b ①⑧⑨、2c、闸口 B1。

    python3 gerber_check.py <GERBER.zip | gerber目录> [--min-drill 0.3] [--min-via-pad 0.45]
                            [--small-region 20] [--json out.json]
    python3 gerber_check.py --cam <板厂 CAM 回读的 Gerber 格式钻孔文件，如 ok/drl> [--boards N]

纯标准库，系统 python3 即可。认 KiCad（X2 属性 / .gtl .gbl .g1… .gto .gm1 .drl）
和嘉立创命名（Gerber_TopLayer.GTL、Drill_PTH_Through.DRL…）两种。

检查项：
  ① 钻孔表      每个 Excellon 文件的刀具表（mm）+ 每把刀的孔数；PTH/过孔最小钻头 ≥ --min-drill
  ② 过孔盘径    铜层里 X2 标为 ViaPad 的圆光圈（没有 X2 时退化为所有 <0.75mm 的圆光圈）≥ --min-via-pad
  ③ 丝印越界    丝印层所有坐标点必须在板框内：先按包围盒(±0.05)数，再按板框真实多边形（含缺口/内孔，贴边 0.05mm 内不算）数
  ④ 泪滴        外层铜的 G36/G37 填充区域个数 + 小区域（≤ --small-region 顶点）个数；
                有泪滴应是“几百个”，个位数～几十个 = 没加上（规则 2c：菜单点了 ≠ 生效）
  ⑤ 板子尺寸    板框外形尺寸；< 70×70mm 做 SMT 要拼板（嘉立创上机下限）
  --cam 模式    板厂 CAM 输出的钻孔（%MOIN% 英寸等）逐光圈数孔，按孔径从小到大列出，
                核“最小钻头 ≥ 下限”和“总孔数 = 每板孔数 × 小板数 + 工艺边孔”
"""
import argparse, collections, io, json, math, os, re, sys, zipfile


# ------------------------------------------------------------------ 读文件
def load_files(src):
    out = {}
    if os.path.isdir(src):
        for root, _d, fs in os.walk(src):
            for f in fs:
                p = os.path.join(root, f)
                with open(p, 'rb') as fh:
                    out[os.path.relpath(p, src)] = fh.read().decode('utf8', 'replace')
    else:
        z = zipfile.ZipFile(src)
        for n in z.namelist():
            if not n.endswith('/'):
                out[n] = z.read(n).decode('utf8', 'replace')
    return out


def classify(name, text):
    """返回 (类别, 细节)：copper/silk/profile/drill/other。"""
    m = re.search(r'%TF\.FileFunction,([^*]*)\*%', text)
    if m:
        ff = m.group(1).split(',')
        if ff[0] == 'Copper':
            side = ff[2] if len(ff) > 2 else ''
            return 'copper', ('Top' if side == 'Top' else 'Bot' if side == 'Bot' else 'Inr')
        if ff[0] == 'Legend':
            return 'silk', ff[1] if len(ff) > 1 else ''
        if ff[0] == 'Profile':
            return 'profile', ''
        if ff[0] in ('Plated', 'NonPlated'):
            return 'gdrill', ff[0]
        return 'other', ff[0]
    if re.search(r'^M48', text, re.M) or re.search(r'^T\d+C[\d.]+', text, re.M):
        return 'drill', ''
    n = name.lower()
    base = os.path.basename(n)
    if re.search(r'\.(gtl)$|toplayer', base):
        return 'copper', 'Top'
    if re.search(r'\.(gbl)$|bottomlayer', base):
        return 'copper', 'Bot'
    if re.search(r'\.g\d+$|innerlayer|\.gp\d$', base):
        return 'copper', 'Inr'
    if re.search(r'\.(gto)$|topsilk', base):
        return 'silk', 'Top'
    if re.search(r'\.(gbo)$|bottomsilk', base):
        return 'silk', 'Bot'
    if re.search(r'\.(gm1|gko|gml)$|boardoutline|edge_cuts', base):
        return 'profile', ''
    return 'other', ''


# ------------------------------------------------------------------ Gerber 解析
def gerber_scale(text):
    m = re.search(r'%FSLAX(\d)(\d)Y(\d)(\d)\*%', text)
    dec = int(m.group(2)) if m else 6
    unit = 25.4 if re.search(r'%MOIN\*%', text) else 1.0
    return unit / (10 ** dec)


def gerber_walk(text):
    """逐条产出 (op, x, y, i, j, 当前光圈, 插补模式, 是否在区域内)，坐标单位 mm；支持模态坐标。"""
    sc = gerber_scale(text)
    x = y = 0.0
    ap = None
    interp = 'G01'
    region = False
    for raw in re.split(r'\*', text):
        s = raw.strip().lstrip('%').strip()
        if not s:
            continue
        if s.startswith('G36'):
            region = True
            yield ('G36', x, y, 0, 0, ap, interp, region)
            continue
        if s.startswith('G37'):
            region = False
            yield ('G37', x, y, 0, 0, ap, interp, region)
            continue
        for g in re.findall(r'G0?([123])(?!\d)', s[:4]):
            interp = 'G0' + g
        m = re.match(r'^(?:G0?[123])?(?:G54)?D(\d+)$', s)
        if m and int(m.group(1)) >= 10:
            ap = m.group(1)
            continue
        m = re.match(r'^(?:G0?[123])?(?:X(-?\d+))?(?:Y(-?\d+))?(?:I(-?\d+))?(?:J(-?\d+))?D0?([123])$', s)
        if m:
            nx = int(m.group(1)) * sc if m.group(1) else x
            ny = int(m.group(2)) * sc if m.group(2) else y
            i = int(m.group(3)) * sc if m.group(3) else 0.0
            j = int(m.group(4)) * sc if m.group(4) else 0.0
            yield ('D0' + m.group(5), nx, ny, i, j, ap, interp, region, x, y)
            x, y = nx, ny


def apertures(text):
    """{D码: (形状, 尺寸mm, AperFunction)}"""
    sc = 25.4 if re.search(r'%MOIN\*%', text) else 1.0
    out, func = {}, ''
    for m in re.finditer(r'%TA\.AperFunction,([^*]*)\*%|%TD\*%|%ADD(\d+)([A-Za-z_][\w.]*),?([\d.X]*)\*%', text):
        if m.group(1) is not None:
            func = m.group(1)
        elif m.group(0) == '%TD*%':
            func = ''
        else:
            dims = [float(v) * sc for v in m.group(4).split('X') if v] if m.group(4) else []
            out[m.group(2)] = (m.group(3), dims, func)
    return out


def arc_points(x0, y0, x1, y1, i, j, cw, n=16):
    cx, cy = x0 + i, y0 + j
    a0 = math.atan2(y0 - cy, x0 - cx)
    a1 = math.atan2(y1 - cy, x1 - cx)
    r = math.hypot(x0 - cx, y0 - cy)
    if cw:
        while a1 >= a0:
            a1 -= 2 * math.pi
    else:
        while a1 <= a0:
            a1 += 2 * math.pi
    if abs(x0 - x1) < 1e-9 and abs(y0 - y1) < 1e-9:  # 整圆
        a1 = a0 + (-2 * math.pi if cw else 2 * math.pi)
    return [(cx + r * math.cos(a0 + (a1 - a0) * k / n), cy + r * math.sin(a0 + (a1 - a0) * k / n)) for k in range(1, n + 1)]


def profile_loops(text):
    segs = []
    for ev in gerber_walk(text):
        if ev[0] != 'D01':
            continue
        op, x, y, i, j, ap, interp, reg, px, py = ev
        if interp in ('G02', 'G03'):
            pts = [(px, py)] + arc_points(px, py, x, y, i, j, interp == 'G02')
        else:
            pts = [(px, py), (x, y)]
        segs.extend(zip(pts, pts[1:]))
    return segs


def dist_edge(segs, x, y):
    best = 1e9
    for (x1, y1), (x2, y2) in segs:
        dx, dy = x2 - x1, y2 - y1
        L = dx * dx + dy * dy
        t = 0 if L == 0 else max(0.0, min(1.0, ((x - x1) * dx + (y - y1) * dy) / L))
        best = min(best, math.hypot(x1 + t * dx - x, y1 + t * dy - y))
    return best


def point_in(segs, x, y):
    """偶奇规则：落在外框内且不在内孔/缺口里才算在板内。"""
    c = False
    for (x1, y1), (x2, y2) in segs:
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
            c = not c
    return c


# ------------------------------------------------------------------ Excellon
def excellon(text):
    unit = 25.4 if re.search(r'^(INCH|M72)', text, re.M) else 1.0
    tools, func, plated = {}, '', None
    m = re.search(r'TF\.FileFunction,(Plated|NonPlated)', text)
    if m:
        plated = m.group(1) == 'Plated'
    hits = collections.Counter()
    cur = None
    body = False
    for line in text.splitlines():
        s = line.strip()
        mf = re.match(r';\s*#@!\s*TA\.AperFunction,(.*)', s)
        if mf:
            func = mf.group(1)
            continue
        if s == '%' or s.startswith('M95'):
            body = True
            continue
        mt = re.match(r'^T(\d+)C([\d.]+)', s)
        if mt:
            tools[int(mt.group(1))] = dict(d=round(float(mt.group(2)) * unit, 4), func=func)
            continue
        mt = re.match(r'^T(\d+)$', s)
        if mt:
            cur = int(mt.group(1))
            continue
        if cur and (s[:1] in ('X', 'Y') or s.startswith('G00') or 'G85' in s):
            hits[cur] += 1  # 普通孔 / G85 槽 / 铣槽起点(G00) 各算 1 个；G01 铣槽中间段不算
    return tools, hits, plated


# ------------------------------------------------------------------ main
def cam_mode(path, boards):
    text = open(path, encoding='utf8', errors='replace').read()
    aps = apertures(text)
    cnt = collections.Counter()
    for ev in gerber_walk(text):
        if ev[0] == 'D03' and ev[5] in aps:
            cnt[ev[5]] += 1
    rows = sorted(cnt.items(), key=lambda kv: aps[kv[0]][1][0] if aps[kv[0]][1] else 0)
    tot = 0
    for k, n in rows:
        d = aps[k][1][0] if aps[k][1] else 0
        print(f'   D{k:>3}  {d:.3f} mm  × {n}')
        tot += n
    print(f'   总孔数 {tot}' + (f'；÷ {boards} 块小板 = {tot / boards:.2f}（能整除才说明没漏没多，工艺边孔另计）' if boards else ''))
    if rows:
        print(f'   最小钻头 {min(aps[k][1][0] for k, _ in rows if aps[k][1]):.3f} mm')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('src', nargs='?')
    ap.add_argument('--cam', help='板厂 CAM 的 Gerber 格式钻孔文件')
    ap.add_argument('--boards', type=int, default=0)
    ap.add_argument('--min-drill', type=float, default=0.3)
    ap.add_argument('--min-via-pad', type=float, default=0.45)
    ap.add_argument('--small-region', type=int, default=20)
    ap.add_argument('--json')
    a = ap.parse_args()
    if a.cam:
        print(f'CAM 钻孔回读 {a.cam}')
        cam_mode(a.cam, a.boards)
        return
    if not a.src:
        ap.error('需要 GERBER.zip 或目录')
    files = load_files(a.src)
    cls = {n: classify(n, t) for n, t in files.items()}
    res = dict(errors=[], warnings=[])
    print(f'源：{a.src}（{len(files)} 个文件）—— 下单页「检查订单」第一行文件名必须与此逐字相同')
    for n in sorted(files):
        print(f'   {cls[n][0]:8} {cls[n][1]:9} {n}')

    # ① 钻孔
    print('\n① 钻孔表（mm）')
    drills = {}
    for n in sorted(files):
        c = cls[n][0]
        if c != 'drill':
            continue
        tools, hits, plated = excellon(files[n])
        kind = 'NPTH' if (plated is False or 'npth' in n.lower()) else 'PTH'
        drills[n] = dict(kind=kind, tools={t: dict(v, hits=hits.get(t, 0)) for t, v in tools.items()})
        desc = ', '.join(f"T{t}={v['d']}({hits.get(t, 0)}{'·过孔' if 'Via' in v['func'] else ''})" for t, v in sorted(tools.items()))
        print(f'   {n} [{kind}] {desc}')
        for t, v in tools.items():
            if kind == 'PTH' and v['d'] < a.min_drill - 1e-6 and hits.get(t, 0):
                msg = f'{n} T{t} 钻头 {v["d"]}mm < {a.min_drill}mm（{hits.get(t, 0)} 孔）—— 板厂会改档加钱'
                res['errors'].append(msg)
                print('      ❌ ' + msg)
    if not drills:
        res['errors'].append('没找到 Excellon 钻孔文件')
        print('   ❌ 没找到钻孔文件')

    # ② 过孔盘径
    print('\n② 铜层小圆光圈（过孔盘）')
    for n in sorted(files):
        if cls[n][0] != 'copper':
            continue
        aps = apertures(files[n])
        via = sorted({v[1][0] for v in aps.values() if v[0] == 'C' and v[1] and 'ViaPad' in v[2]})
        src = 'ViaPad(X2)'
        if '%TA.AperFunction' not in files[n]:
            via = sorted({v[1][0] for v in aps.values() if v[0] == 'C' and v[1] and v[1][0] < 0.75})
            src = '所有<0.75 圆光圈(无X2)'
        print(f'   {n}: {src} {via}')
        bad = [d for d in via if d < a.min_via_pad - 1e-6]
        if bad:
            msg = f'{n} 过孔盘径 {bad} < {a.min_via_pad}mm'
            res['errors'].append(msg)
            print('      ❌ ' + msg)

    # ③ 丝印越界 + ⑤ 尺寸
    prof = [n for n in files if cls[n][0] == 'profile']
    print('\n③ 丝印越界')
    if not prof:
        res['errors'].append('没找到板框(Profile/Edge_Cuts/GKO)')
        print('   ❌ 没找到板框文件')
    else:
        segs = profile_loops(files[prof[0]])
        xs = [p[0] for s in segs for p in s]
        ys = [p[1] for s in segs for p in s]
        W, H = max(xs) - min(xs), max(ys) - min(ys)
        res['board_mm'] = (round(W, 2), round(H, 2))
        for n in sorted(files):
            if cls[n][0] != 'silk':
                continue
            pts = [(ev[1], ev[2]) for ev in gerber_walk(files[n]) if ev[0] in ('D01', 'D02', 'D03')]
            out_bb = [p for p in pts if not (min(xs) - .05 <= p[0] <= max(xs) + .05 and min(ys) - .05 <= p[1] <= max(ys) + .05)]
            out_pg = [p for p in pts if not point_in(segs, *p) and dist_edge(segs, *p) > 0.05]  # 贴边(圆弧弦差)不算
            flag = '✅' if not out_pg else '❌'
            print(f'   {flag} {n}: 包围盒外 {len(out_bb)}/{len(pts)}，板框多边形外 {len(out_pg)}/{len(pts)}')
            if out_pg:
                # 聚类：按 2mm 网格归并，直接定位是哪几个字跑出去
                cl = collections.Counter((round(p[0] / 2) * 2, round(p[1] / 2) * 2) for p in out_pg)
                print('      越界点聚类(2mm 网格, 点数)：', cl.most_common(8))
                res['errors'].append(f'{n} 丝印越界 {len(out_pg)} 点')
        print(f'\n⑤ 板子外形 {W:.2f} × {H:.2f} mm' + (
            '  ⚠ 小于 70×70mm：嘉立创 SMT 必须拼板（样板至少 5 大板，特价/免费券失效）' if (W < 70 or H < 70) else ''))

    # ④ 泪滴
    print(f'\n④ 泪滴：外层铜 G36/G37 区域（小区域 = ≤{a.small_region} 顶点）')
    td = {}
    for n in sorted(files):
        if cls[n] not in (('copper', 'Top'), ('copper', 'Bot')):
            continue
        sizes, cur = [], None
        for ev in gerber_walk(files[n]):
            if ev[0] == 'G36':
                cur = 0
            elif ev[0] == 'G37':
                if cur is not None:
                    sizes.append(cur)
                cur = None
            elif ev[0] == 'D01' and cur is not None:
                cur += 1
        small = sum(1 for s in sizes if s <= a.small_region)
        td[n] = dict(regions=len(sizes), small=small, big=sum(1 for s in sizes if s > 100))
        print(f'   {n}: 区域 {len(sizes)}，小区域 {small}，大区域(>100 顶点) {td[n]["big"]}')
    res['teardrop'] = td
    if td and all(v['small'] < 30 for v in td.values()):
        res['warnings'].append('外层小区域都很少，疑似没加泪滴（规则 2c）—— 回 KiCad 核「编辑→泪滴」并重新填充覆铜')
        print('   ⚠ ' + res['warnings'][-1])

    print(f'\n结论：错误 {len(res["errors"])}，警告 {len(res["warnings"])}')
    for e in res['errors']:
        print('   ❌ ' + e)
    res['drills'] = drills
    if a.json:
        json.dump(res, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    sys.exit(1 if res['errors'] else 0)


if __name__ == '__main__':
    main()
